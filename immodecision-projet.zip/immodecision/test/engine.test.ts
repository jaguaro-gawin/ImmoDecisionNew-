import { test, expect } from 'vitest';

import { annuity, schedule } from '../src/core/loan';
import { npv, irr, discountedPayback, signChanges } from '../src/core/cashflow';
import { rentalTax, capitalGainTax } from '../src/core/tax';
import { analyze } from '../src/core/analyze';
import { rank, normalise } from '../src/core/scoring';
import { stability, tippingPoints, scenarios } from '../src/core/robustness';
import { validateAlternative, validateSettings } from '../src/core/validation';
import { makeAlternative, defaultSettings, rebalanceWeights, displayWeights } from '../src/core/model';
import type { Alternative, Settings } from '../src/core/types';

const close = (actual: number | null, expected: number, tolerance: number, label: string): void => {
  expect(actual, label).not.toBeNull();
  expect(Math.abs(actual! - expected), `${label} : attendu ${expected} ± ${tolerance}`)
    .toBeLessThanOrEqual(tolerance);
};

/* ── Référence documentée ───────────────────────────────────────────────────
   Reprise de l'exemple chiffré de la fiche descriptive, hypothèses d'origine :
   ni frais d'acquisition, ni vacance, ni fiscalité. Ce test verrouille la
   continuité du moteur avec les chiffres déjà publiés dans le rapport.      */

const referenceSettings: Settings = {
  ...defaultSettings(),
  horizonYears: 10,
  discountRate: 4,
  dscrThreshold: 1.2,
  taxRegime: 'none',
};

const referenceAlternative = (overrides: Partial<Alternative> = {}): Alternative => makeAlternative({
  price: 200000,
  acquisitionFeeRate: 0,
  monthlyRent: 1100,
  vacancyRate: 0,
  rentGrowth: 1.5,
  annualCharges: 1800,
  chargesGrowth: 2.5,
  resaleValue: 230000,
  downPayment: 80000,
  loanRate: 4.2,
  loanYears: 20,
  ...overrides,
});

test('alternative A de la fiche descriptive', () => {
  const a = analyze(referenceAlternative(), referenceSettings);
  close(a.annuity, 8987, 1, 'échéance annuelle');
  close(a.dscrMin, 1.269, 0.001, 'DSCR minimum');
  close(a.npv, 51543, 5, 'VAN');
  close(a.irr, 9.889, 0.005, 'TRI');
  close(a.finalBalance, 72171, 5, 'capital restant dû à 10 ans');
  close(a.resistance, 0.054, 0.001, 'marge de résistance');
  expect(a.feasible).toBe(true);
});

test('alternative B de la fiche descriptive', () => {
  const b = analyze(referenceAlternative({ downPayment: 100000, loanRate: 4 }), referenceSettings);
  close(b.annuity, 7358, 1, 'échéance annuelle');
  close(b.dscrMin, 1.549, 0.001, 'DSCR minimum');
  close(b.npv, 53191, 5, 'VAN');
  close(b.irr, 9.218, 0.005, 'TRI');
  close(b.resistance, 0.225, 0.001, 'marge de résistance');
});

test('B devance A avec le profil équilibré', () => {
  const analyses = [
    analyze(referenceAlternative({ name: 'A' }), referenceSettings),
    analyze(referenceAlternative({ name: 'B', downPayment: 100000, loanRate: 4 }), referenceSettings),
  ];
  const { ranked } = rank(analyses, { npv: 30, irr: 30, yield: 15, dscrMargin: 25 });
  expect(ranked[0]!.analysis.name).toBe('B');
});

/* ── Échéancier ─────────────────────────────────────────────────────────── */

test('annuité nulle sans capital emprunté', () => {
  expect(annuity(0, 4, 20)).toBe(0);
});

test('taux nul : amortissement linéaire', () => {
  close(annuity(100000, 0, 10), 10000, 1e-9, 'annuité à taux nul');
});

test('le capital restant dû s\u2019annule au terme', () => {
  const { rows } = schedule({ principal: 120000, rate: 4.2, years: 20 }, 20);
  close(rows[19]!.balance, 0, 1e-6, 'solde final');
});

test('le prêt s\u2019arrête au terme même si la détention se poursuit', () => {
  const { rows } = schedule({ principal: 100000, rate: 3, years: 5 }, 8);
  expect(rows[5]!.debtService).toBe(0);
  expect(rows[7]!.active).toBe(false);
});

/* ── VAN et TRI ─────────────────────────────────────────────────────────── */

test('la VAN au TRI est nulle', () => {
  const cf = [-100000, 20000, 25000, 30000, 60000];
  const { rate, status } = irr(cf);
  expect(status).toBe('ok');
  close(npv(cf, rate!), 0, 1e-4, 'VAN au TRI');
});

test('des flux sans racine sont signalés, pas inventés', () => {
  // Apport quasi nul, flux tous positifs ensuite : le TRI n'existe pas sur
  // l'intervalle balayé. La VAN reste le seul repère valide.
  const { rate, status } = irr([-100, 20000, 20000, 20000]);
  expect(status).toBe('none');
  expect(rate).toBe(null);
});

test('les flux non conventionnels sont détectés', () => {
  expect(signChanges([-100, 60, -40, 90])).toBe(3);
});

test('délai de récupération actualisé', () => {
  const payback = discountedPayback([-100, 50, 50, 50], 0);
  close(payback, 2, 1e-9, 'délai de récupération');
});

/* ── Fiscalité ──────────────────────────────────────────────────────────── */

test('micro-foncier : abattement de 30 %', () => {
  const { tax } = rentalTax('micro', { grossRent: 10000, charges: 2000, interest: 3000 }, { marginalTaxRate: 30, socialRate: 17.2 });
  close(tax, 10000 * 0.7 * 0.472, 1e-6, 'impôt micro-foncier');
});

test('régime réel : déficit reporté, pas perdu', () => {
  const rates = { marginalTaxRate: 30, socialRate: 17.2 };
  const first = rentalTax('reel', { grossRent: 10000, charges: 3000, interest: 9000 }, rates);
  expect(first.tax).toBe(0);
  close(first.carriedDeficit, 2000, 1e-9, 'déficit reporté');
  const second = rentalTax('reel', { grossRent: 10000, charges: 3000, interest: 5000 }, rates, first.carriedDeficit);
  close(second.base, 0, 1e-9, 'base imposable après imputation');
});

test('plus-value : exonération d\u2019impôt sur le revenu à 22 ans', () => {
  const { incomeTax, socialTax } = capitalGainTax(
    { resaleValue: 300000, acquisitionCost: 200000, holdingYears: 22 },
    { socialRate: 17.2 },
  );
  close(incomeTax, 0, 1e-9, 'IR sur la plus-value');
  expect(socialTax > 0, 'les prélèvements sociaux restent dus').toBe(true);
});

test('plus-value : exonération totale à 30 ans', () => {
  const { tax } = capitalGainTax(
    { resaleValue: 300000, acquisitionCost: 200000, holdingYears: 30 },
    { socialRate: 17.2 },
  );
  close(tax, 0, 1e-9, 'impôt total');
});

test('pas d\u2019impôt sur une moins-value', () => {
  const { tax } = capitalGainTax(
    { resaleValue: 150000, acquisitionCost: 200000, holdingYears: 10 },
    { socialRate: 17.2 },
  );
  expect(tax).toBe(0);
});

/* ── Faisabilité et levier ──────────────────────────────────────────────── */

test('une seule année sous le seuil écarte l\u2019alternative', () => {
  const alt = referenceAlternative({ downPayment: 20000, loanRate: 5 });
  const a = analyze(alt, referenceSettings);
  expect(a.feasible).toBe(a.dscrMin! >= referenceSettings.dscrThreshold);
  expect(a.feasible).toBe(false);
});

test('un achat comptant n\u2019a pas de contrainte bancaire', () => {
  const a = analyze(referenceAlternative({ downPayment: 200000 }), referenceSettings);
  expect(a.hasDebt).toBe(false);
  expect(a.dscrMin).toBe(null);
  expect(a.feasible).toBe(true);
  expect(normalise('dscrMargin', a, { min: 0, max: 1 })).toBe(1);
});

test('le levier joue tant que le crédit coûte moins que le bien ne rapporte', () => {
  const a = analyze(referenceAlternative(), referenceSettings);
  expect(a.leverage!, 'effet de levier positif attendu').toBeGreaterThan(0);
  close(a.unleveredIrr, 7.09, 0.01, 'TRI sans emprunt');
});

/* ── Frais d'acquisition ────────────────────────────────────────────────── */

test('les frais d\u2019acquisition dégradent la rentabilité', () => {
  const withoutFees = analyze(referenceAlternative(), referenceSettings);
  const withFees = analyze(referenceAlternative({ acquisitionFeeRate: 7.5 }), referenceSettings);
  expect(withFees.npv < withoutFees.npv, 'la VAN doit baisser').toBe(true);
  expect(withFees.netYield < withoutFees.netYield, 'le rendement net doit baisser').toBe(true);
});

/* ── Pondération ────────────────────────────────────────────────────────── */

test('les poids somment toujours à 100', () => {
  const w = rebalanceWeights({ npv: 30, irr: 30, yield: 15, dscrMargin: 25 }, 'irr', 70);
  close(Object.values(w).reduce((s, v) => s + v, 0), 100, 1e-9, 'somme des poids');
  close(w.irr, 70, 1e-9, 'poids ciblé');
});

test('les pourcentages affichés somment à 100', () => {
  const shown = displayWeights({ npv: 33.3333, irr: 33.3333, yield: 16.6667, dscrMargin: 16.6667 });
  expect(Object.values(shown).reduce((sum, v) => sum + v, 0)).toBe(100);
});

test('un critère constant ne discrimine pas', () => {
  const analyses = [
    analyze(referenceAlternative({ name: 'X' }), referenceSettings),
    analyze(referenceAlternative({ name: 'Y' }), referenceSettings),
  ];
  const { ranked } = rank(analyses, { npv: 25, irr: 25, yield: 25, dscrMargin: 25 });
  close(ranked[0]!.score, 1, 1e-9, 'score de deux alternatives identiques');
});

/* ── Robustesse ─────────────────────────────────────────────────────────── */

const twoAlternatives = () => [
  analyze(referenceAlternative({ name: 'A' }), referenceSettings),
  analyze(referenceAlternative({ name: 'B', downPayment: 100000, loanRate: 4 }), referenceSettings),
];

test('la stabilité est déterministe', () => {
  const analyses = twoAlternatives();
  const first = stability(analyses, { npv: 30, irr: 30, yield: 15, dscrMargin: 25 }, { samples: 300 });
  const second = stability(analyses, { npv: 30, irr: 30, yield: 15, dscrMargin: 25 }, { samples: 300 });
  expect(first.entries).toEqual(second.entries);
});

test('les fréquences de victoire somment à 1', () => {
  const { entries } = stability(twoAlternatives(), { npv: 30, irr: 30, yield: 15, dscrMargin: 25 }, { samples: 400 });
  close(entries.reduce((s, e) => s + e.winRate, 0), 1, 1e-9, 'somme des fréquences');
});

test('le point de bascule sur le TRI est identifié', () => {
  const points = tippingPoints(twoAlternatives(), { npv: 30, irr: 30, yield: 15, dscrMargin: 25 });
  const irrPoint = points.find((p) => p.key === 'irr')!;
  expect(irrPoint.tipping, 'un poids de bascule doit exister sur le TRI').not.toBeNull();
  expect(irrPoint.newLeader).toBe('A');
});

test('un choc de loyer dégrade le DSCR', () => {
  const alternatives = [referenceAlternative({ name: 'A' })];
  const table = scenarios(alternatives, referenceSettings);
  const base = table.find((s) => s.shock === 'base')!.results[0]!;
  const shocked = table.find((s) => s.shock === 'rent')!.results[0]!;
  expect(shocked.dscrMin!).toBeLessThan(base.dscrMin!);
  expect(shocked.feasible).toBe(false);
});

/* ── Validation ─────────────────────────────────────────────────────────── */

test('un prix nul est une erreur bloquante', () => {
  const issues = validateAlternative(referenceAlternative({ price: 0 }), defaultSettings());
  expect(issues.some((i) => i.field === 'price' && i.level === 'error')).toBe(true);
});

test('un apport supérieur au coût total est signalé sans bloquer', () => {
  const issues = validateAlternative(referenceAlternative({ downPayment: 500000 }), defaultSettings());
  const issue = issues.find((i) => i.field === 'downPayment')!;
  expect(issue.level).toBe('warning');
});

test('un seuil DSCR sous 1 est signalé', () => {
  const issues = validateSettings({ ...defaultSettings(), dscrThreshold: 0.8 });
  expect(issues.some((i) => i.field === 'dscrThreshold' && i.level === 'warning')).toBe(true);
});
