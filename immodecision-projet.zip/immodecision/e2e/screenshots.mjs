/**
 * Revue visuelle et test de fumée — pilote le fichier réellement livré.
 *
 * Une suite de tests dit qu'un bouton existe ; elle ne dit pas qu'il est
 * lisible. Ce script parcourt les cinq étapes, vérifie les points critiques
 * et écrit une capture par écran dans `shots/`.
 */

import { chromium } from 'playwright';
import { mkdir } from 'node:fs/promises';

const FILE = `file://${process.cwd()}/dist/index.html`;
let failures = 0;

const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failures += 1;
};

await mkdir('shots', { recursive: true });

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 2 });

const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });

await page.goto(FILE);
await page.waitForSelector('.rail-step');

const step = async (label) => {
  await page.click(`.rail-step:has-text("${label}")`);
  await page.waitForTimeout(200);
};

check('rail des cinq étapes', await page.locator('.rail-step').count() === 5);

await step('Alternatives');
check('trois alternatives', await page.locator('.alt-card').count() === 3);
check(
  'résumé chiffré vivant',
  (await page.locator('.alt-summary-items').first().textContent())?.includes('k€'),
);
await page.screenshot({ path: 'shots/2-alternatives.png', fullPage: true });

// Régression : une virgule tapée dans un champ décimal doit survivre au
// réaffichage, sinon le taux « 4,2 » devient « 42 » sous les doigts.
const rate = page.locator('input[data-field$="-loanRate"]').first();
await rate.click();
await rate.press('Control+a');
await rate.type('4,25', { delay: 30 });
check('virgule décimale préservée', await rate.inputValue() === '4,25', await rate.inputValue());
await rate.press('Control+a');
await rate.type('4,2', { delay: 30 });
await rate.blur();

await step('Priorités');
check('quatre curseurs de poids', await page.locator('.weight-slider').count() === 4);
await page.locator('.weight-slider').first().fill('60');
await page.waitForTimeout(120);
const weights = await page.locator('.weight-value').allTextContents();
const total = weights.reduce((sum, text) => sum + parseInt(text, 10), 0);
check('somme des poids affichés = 100', total === 100, weights.join(' + '));
await page.screenshot({ path: 'shots/3-priorites.png', fullPage: true });

await page.click('.btn:has-text("Valider")');
await page.waitForTimeout(200);

await step('Calculs');
check('projection sur dix ans', await page.locator('.table-dense tbody tr').count() === 10);
check('graphique DSCR rendu', await page.locator('.recharts-line').count() > 0);
await page.screenshot({ path: 'shots/4-calculs.png', fullPage: true });

await step('Résultat');
check('verdict affiché', (await page.locator('.verdict-name').textContent())?.length > 0);
check('plan de décision rendu', await page.locator('.chart-plane .recharts-surface').count() > 0);
check('barres de stabilité', await page.locator('.stability-row').count() > 0);
check('une seule tête de classement', await page.locator('.row-leader').count() === 1);
await page.screenshot({ path: 'shots/5-resultat.png', fullPage: true });

await step('Hypothèses');
await page.screenshot({ path: 'shots/1-hypotheses.png', fullPage: true });

check('aucune erreur console', errors.length === 0, errors.join(' | '));

await browser.close();
console.log(failures ? `\n${failures} vérification(s) en échec.` : '\nToutes les vérifications passent.');
process.exit(failures ? 1 : 0);
