import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

/**
 * La livraison attendue est un fichier ouvrable par double-clic, sans serveur
 * ni réseau. `viteSingleFile` inline le JavaScript et la feuille de style dans
 * `index.html` ; le développement, lui, garde le rechargement à chaud.
 */
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  build: {
    outDir: 'dist',
    assetsInlineLimit: 100_000_000,
    cssCodeSplit: false,
    reportCompressedSize: false,
  },
  test: {
    environment: 'node',
    include: ['test/**/*.test.ts'],
  },
});
