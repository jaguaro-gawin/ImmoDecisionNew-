/**
 * Export CSV — séparateur point-virgule et virgule décimale, pour qu'un
 * tableur configuré en français ouvre le fichier sans écran d'import.
 */

type Cell = string | number | null | undefined;

const format = (value: Cell): string => {
  if (value === null || value === undefined) return '';
  if (typeof value === 'number') {
    return String(Math.round(value * 100) / 100).replace('.', ',');
  }
  // Échappement : un point-virgule ou un guillemet dans un intitulé casserait
  // sinon la colonne.
  return /[";\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
};

export const toCsv = (rows: Cell[][]): string =>
  rows.map((row) => row.map(format).join(';')).join('\n');

/** Le BOM signale l'UTF-8 à Excel, sans lequel les accents se perdent. */
export function downloadCsv(filename: string, content: string): void {
  const blob = new Blob([`\uFEFF${content}`], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
