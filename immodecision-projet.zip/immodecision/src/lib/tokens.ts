/**
 * Jetons de couleur partagés entre la feuille de style et les graphiques.
 *
 * Recharts attend des couleurs concrètes en propriétés, là où le CSS travaille
 * avec des variables. Ces constantes sont l'unique point de duplication : elles
 * doivent rester alignées sur `:root` dans `styles/app.css`.
 */
export const COLORS = {
  ink: '#141A24',
  ink2: '#4E5868',
  ink3: '#88919F',
  rule: '#E4E8EF',
  surface: '#FFFFFF',
  surface2: '#F3F5F9',
  brand: '#3A4EC0',
  brandDeep: '#202B6B',
  brandSoft: '#7B8AE0',
  brandWash: '#EEF0FD',
  reject: '#BE2F4B',
  rejectWash: '#FDEFF1',
} as const;
