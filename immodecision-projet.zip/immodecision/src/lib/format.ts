/**
 * Formatage — seule couche autorisée à convertir des euros en k€.
 * Le moteur ne connaît que l'euro ; l'affichage abrège.
 */

const MISSING = '—';

const nf = (min: number, max: number): Intl.NumberFormat =>
  new Intl.NumberFormat('fr-FR', { minimumFractionDigits: min, maximumFractionDigits: max });

const integer = nf(0, 0);
const oneDecimal = nf(1, 1);
const twoDecimals = nf(2, 2);

const isNumber = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

/** Montant en euros, abrégé en k€ au-delà de 10 000 €. */
export function money(value: number | null | undefined): string {
  if (!isNumber(value)) return MISSING;
  return Math.abs(value) >= 10000
    ? `${oneDecimal.format(value / 1000)} k€`
    : `${integer.format(Math.round(value))} €`;
}

/** Montant sans suffixe, pour les colonnes déjà titrées. */
export const amount = (value: number | null | undefined): string =>
  (isNumber(value) ? integer.format(Math.round(value)) : MISSING);

export const percent = (value: number | null | undefined, decimals = 2): string =>
  (isNumber(value) ? `${nf(decimals, decimals).format(value)} %` : MISSING);

export const points = (value: number | null | undefined, decimals = 2): string =>
  (isNumber(value) ? `${value > 0 ? '+' : ''}${nf(decimals, decimals).format(value)} pts` : MISSING);

export const ratio = (value: number | null | undefined): string =>
  (isNumber(value) ? twoDecimals.format(value) : MISSING);

export const score = (value: number | null | undefined): string =>
  (isNumber(value) ? nf(3, 3).format(value) : MISSING);

/** Marge de résistance : le pourcentage seul reste abstrait, les mois parlent. */
export function resistance(value: number | null | undefined): string {
  if (!isNumber(value)) return MISSING;
  if (value <= 0) return 'Aucune';
  const months = value * 12;
  const duration = months < 1 ? `${Math.round(months * 30)} j` : `${oneDecimal.format(months)} mois`;
  return `${oneDecimal.format(value * 100)} % · ${duration}`;
}

export const years = (value: number | null | undefined): string =>
  (isNumber(value) ? `${oneDecimal.format(value)} ans` : 'Jamais');

export const date = (iso: string): string =>
  new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });

/** Valeur mise en forme pour un champ de saisie au repos. */
export function editable(value: number | null | undefined): string {
  if (!isNumber(value)) return '';
  const decimals = Math.min(4, (String(value).split('.')[1] ?? '').length);
  return nf(decimals, decimals).format(value);
}

/** Lit une saisie numérique en acceptant la virgule décimale et les espaces. */
export function parseNumber(raw: string): number {
  const cleaned = raw.replace(/\s/g, '').replace(',', '.');
  return cleaned === '' ? NaN : Number(cleaned);
}

export { MISSING };
