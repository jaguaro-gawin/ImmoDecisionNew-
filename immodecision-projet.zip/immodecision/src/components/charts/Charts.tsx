/**
 * Graphiques.
 *
 * Recharts porte les axes, les graduations, les info-bulles et le
 * redimensionnement — tout ce qui était calculé à la main auparavant, et qui
 * produisait des graduations dupliquées par arrondi. Ne reste ici que ce qui
 * appartient au domaine : où passe le mur bancaire, quelle année est la plus
 * fragile, quelle alternative est recommandée.
 */

import {
  Bar, BarChart, Cell, CartesianGrid, Label, LabelList, Line, LineChart, ReferenceArea,
  ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis,
} from 'recharts';

import { COLORS } from '../../lib/tokens';
import { money, percent, ratio } from '../../lib/format';
import type { Analysis } from '../../core/types';
import type { StabilityEntry } from '../../core/robustness';

const axis = { stroke: COLORS.ink3, fontSize: 12 } as const;
const tooltipStyle = {
  contentStyle: {
    background: COLORS.surface,
    border: `1px solid ${COLORS.rule}`,
    borderRadius: 8,
    fontSize: 13,
    boxShadow: '0 8px 20px -6px rgba(20,26,36,.16)',
  },
  labelStyle: { color: COLORS.ink, fontWeight: 600 },
} as const;

/* ── Plan de décision ───────────────────────────────────────────────────── */

interface PlanePoint {
  x: number;
  y: number;
  name: string;
  state: 'leader' | 'ok' | 'refused';
}

/**
 * Chaque alternative placée selon sa rentabilité (TRI) et sa résistance — la
 * part de loyer qu'elle peut perdre avant de rompre le seuil. La zone hachurée
 * matérialise l'exigence de la banque : à gauche, aucun financement.
 */
export function DecisionPlane({ analyses, leaderId }: {
  analyses: Analysis[];
  leaderId: string;
}) {
  const points: PlanePoint[] = analyses
    .filter((a) => a.irr !== null)
    .map((a) => ({
      x: (a.resistance ?? 1) * 100,
      y: a.irr!,
      name: a.name,
      state: !a.feasible ? 'refused' : a.id === leaderId ? 'leader' : 'ok',
    }));

  if (!points.length) {
    return <p className="chart-empty">Aucun TRI exploitable : le plan de décision ne peut pas être tracé.</p>;
  }

  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const yPad = Math.max((Math.max(...ys) - Math.min(...ys)) * 0.4, 0.25);
  const xMin = Math.min(-10, Math.floor(Math.min(...xs) / 5) * 5 - 5);
  const xMax = Math.max(20, Math.ceil(Math.max(...xs) / 5) * 5 + 5);

  // Graduations sur des multiples de 5 : les bornes automatiques de Recharts
  // produisent ici des valeurs comme « −1 % » ou « 17 % », illisibles sur un
  // axe dont le seul repère qui compte est le zéro.
  const xTicks: number[] = [];
  const stride = xMax - xMin > 60 ? 10 : 5;
  for (let v = Math.ceil(xMin / stride) * stride; v <= xMax; v += stride) xTicks.push(v);

  const fill = (state: PlanePoint['state']): string =>
    (state === 'leader' ? COLORS.brand : state === 'refused' ? COLORS.rejectWash : COLORS.surface);

  return (
    <div className="chart chart-plane">
      <ResponsiveContainer width="100%" height={380}>
        <ScatterChart margin={{ top: 28, right: 32, bottom: 34, left: 12 }}>
          <defs>
            <pattern id="refused-zone" width={8} height={8} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
              <line x1={0} y1={0} x2={0} y2={8} stroke={COLORS.reject} strokeWidth={1} opacity={0.16} />
            </pattern>
          </defs>

          <CartesianGrid stroke={COLORS.rule} />

          <ReferenceArea x1={xMin} x2={0} fill="url(#refused-zone)" fillOpacity={1} />
          <ReferenceLine x={0} stroke={COLORS.reject} strokeDasharray="5 4" strokeWidth={1.5}>
            <Label value="Seuil bancaire" position="insideTopRight" fill={COLORS.reject} fontSize={12} fontWeight={600} />
          </ReferenceLine>

          <XAxis
            type="number"
            dataKey="x"
            domain={[xMin, xMax]}
            ticks={xTicks}
            tickFormatter={(v: number) => `${v} %`}
            {...axis}
          >
            <Label
              value="Marge de résistance — perte de loyer absorbable avant rupture"
              position="bottom"
              offset={12}
              fill={COLORS.ink3}
              fontSize={12}
            />
          </XAxis>

          <YAxis
            type="number"
            dataKey="y"
            domain={[Math.min(...ys) - yPad, Math.max(...ys) + yPad]}
            tickFormatter={(v: number) => `${v.toFixed(1)} %`}
            width={62}
            {...axis}
          >
            <Label value="TRI des fonds propres" angle={-90} position="insideLeft" fill={COLORS.ink3} fontSize={12} />
          </YAxis>

          <Tooltip
            {...tooltipStyle}
            cursor={{ strokeDasharray: '3 3', stroke: COLORS.ink3 }}
            content={({ payload }) => {
              const point = payload?.[0]?.payload as PlanePoint | undefined;
              if (!point) return null;
              return (
                <div className="tooltip">
                  <strong>{point.name}</strong>
                  <span>TRI {percent(point.y)}</span>
                  <span>Marge {percent(point.x, 1)}</span>
                </div>
              );
            }}
          />

          <Scatter data={points} isAnimationActive={false} shape="circle" legendType="none">
            {points.map((point) => (
              <Cell
                key={point.name}
                fill={fill(point.state)}
                stroke={point.state === 'refused' ? COLORS.reject : COLORS.brand}
                strokeWidth={2}
              />
            ))}
            {/* Sans étiquette, il faut survoler chaque point pour savoir de
                quelle alternative il s'agit — inutilisable à l'impression.
                Le rendu par défaut hérite de la largeur du point et coupe le
                texte mot à mot : on trace donc le libellé nous-mêmes. */}
            <LabelList
              dataKey="name"
              content={({ x, y, index }) => {
                const point = points[Number(index)];
                if (!point) return null;
                return (
                  <text
                    x={Number(x)}
                    y={Number(y) - 14}
                    textAnchor="middle"
                    fontSize={12.5}
                    fontWeight={600}
                    fill={point.state === 'refused' ? COLORS.reject
                      : point.state === 'leader' ? COLORS.brandDeep : COLORS.ink2}
                  >
                    {point.name}
                  </text>
                );
              }}
            />
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>

      <ul className="legend">
        <li><span className="key key-leader" />Recommandée</li>
        <li><span className="key key-ok" />Finançable</li>
        <li><span className="key key-refused" />Écartée par le seuil</li>
      </ul>
    </div>
  );
}

/* ── DSCR année par année ───────────────────────────────────────────────── */

export function DscrChart({ analysis, threshold }: { analysis: Analysis; threshold: number }) {
  const data = analysis.years
    .filter((y) => y.dscr !== null)
    .map((y) => ({ year: y.year, dscr: y.dscr! }));

  if (!data.length) {
    return <p className="chart-empty">Achat comptant : aucune échéance à couvrir.</p>;
  }

  const values = data.map((d) => d.dscr);
  const low = Math.min(threshold * 0.9, Math.min(...values) * 0.97);
  const high = Math.max(threshold * 1.08, Math.max(...values) * 1.03);

  return (
    <div className="chart">
      <ResponsiveContainer width="100%" height={230}>
        <LineChart data={data} margin={{ top: 12, right: 16, bottom: 8, left: 4 }}>
          <CartesianGrid stroke={COLORS.rule} vertical={false} />
          <ReferenceArea y1={low} y2={threshold} fill={COLORS.reject} fillOpacity={0.07} />
          <ReferenceLine y={threshold} stroke={COLORS.reject} strokeDasharray="5 4" strokeWidth={1.5}>
            <Label
              value={`seuil ${threshold.toFixed(2)}`}
              position="insideTopRight"
              fill={COLORS.reject}
              fontSize={11}
              fontWeight={600}
            />
          </ReferenceLine>
          <XAxis dataKey="year" tickFormatter={(v: number) => `An ${v}`} {...axis} />
          <YAxis domain={[low, high]} tickFormatter={(v: number) => v.toFixed(2)} width={48} {...axis} />
          <Tooltip
            {...tooltipStyle}
            formatter={(value) => [ratio(Number(value)), 'DSCR']}
            labelFormatter={(label) => `Année ${String(label)}`}
          />
          <Line
            type="monotone"
            dataKey="dscr"
            stroke={COLORS.brand}
            strokeWidth={2}
            isAnimationActive={false}
            dot={({ cx, cy, payload, index }) => {
              const breaking = payload.dscr < threshold;
              const weakest = payload.year === analysis.weakestYear;
              return (
                <circle
                  key={index}
                  cx={cx}
                  cy={cy}
                  r={weakest ? 5 : 3.5}
                  fill={breaking ? COLORS.reject : weakest ? COLORS.brand : COLORS.surface}
                  stroke={breaking ? COLORS.reject : COLORS.brand}
                  strokeWidth={2}
                />
              );
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ── Flux de trésorerie ─────────────────────────────────────────────────── */

export function CashflowChart({ analysis }: { analysis: Analysis }) {
  const data = analysis.cashflows.map((flow, year) => ({ year, flow }));

  return (
    <div className="chart">
      <ResponsiveContainer width="100%" height={210}>
        <BarChart data={data} margin={{ top: 12, right: 16, bottom: 8, left: 4 }}>
          <CartesianGrid stroke={COLORS.rule} vertical={false} />
          <ReferenceLine y={0} stroke={COLORS.ink3} />
          <XAxis dataKey="year" tickFormatter={(v: number) => `An ${v}`} {...axis} />
          <YAxis tickFormatter={(v: number) => `${Math.round(v / 1000)} k`} width={52} {...axis} />
          <Tooltip
            {...tooltipStyle}
            formatter={(value) => [money(Number(value)), 'Flux net']}
            labelFormatter={(label) => (Number(label) === 0 ? 'Année 0 — apport' : `Année ${String(label)}`)}
            cursor={{ fill: COLORS.surface2 }}
          />
          <Bar dataKey="flow" isAnimationActive={false} radius={[2, 2, 0, 0]}>
            {data.map((entry) => (
              <Cell key={entry.year} fill={entry.flow >= 0 ? COLORS.brand : COLORS.reject} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ── Stabilité du classement ────────────────────────────────────────────── */

export function StabilityBars({ entries }: { entries: StabilityEntry[] }) {
  return (
    <div className="stability">
      {entries.map((entry) => (
        <div className="stability-row" key={entry.id}>
          <span className="stability-name">{entry.name}</span>
          <div className="stability-track">
            <div
              className={`stability-fill${entry.winRate >= 0.5 ? ' strong' : ''}`}
              style={{ width: `${(entry.winRate * 100).toFixed(1)}%` }}
            />
          </div>
          <span className="stability-value num">{(entry.winRate * 100).toFixed(0)} %</span>
        </div>
      ))}
    </div>
  );
}
