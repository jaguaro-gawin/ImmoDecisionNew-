/**
 * Étape 3 — les priorités, fixées avant l'affichage du classement.
 *
 * L'ordre n'est pas anodin. Si l'utilisateur voyait d'abord quelle alternative
 * a la meilleure VAN, il réglerait ses poids pour la faire gagner : le score
 * ne servirait plus à décider, mais à justifier après coup.
 */

import { useApp, useCurrentProject } from '../../store/useApp';
import { Panel, Button, StepNav } from '../ui/Panel';
import { CRITERIA, PROFILES, displayWeights } from '../../core/model';
import type { Project } from '../../core/types';

export function PrioritiesStep() {
  const project = useCurrentProject() as Project;
  const { setWeight, applyProfile, confirmWeights, goStep } = useApp();
  const shown = displayWeights(project.weights);

  return (
    <div className="step">
      <Panel
        title="Priorités"
        caption="Cent points à répartir entre quatre critères. Ce que vous donnez à l'un, les autres le cèdent."
      >
        <div className="profiles">
          <span className="profiles-label">Point de départ</span>
          <div className="profiles-choices">
            {Object.entries(PROFILES).map(([key, def]) => (
              <button
                key={key}
                type="button"
                className={`profile${project.profile === key ? ' profile-active' : ''}`}
                aria-pressed={project.profile === key}
                onClick={() => applyProfile(key)}
              >
                <span className="profile-name">{def.label}</span>
                <span className="profile-detail">
                  {CRITERIA.map((c) => `${c.label} ${def.weights[c.key]}`).join(' · ')}
                </span>
              </button>
            ))}
          </div>
          {project.profile === 'sur-mesure' && (
            <span className="profile-custom">Réglage sur mesure</span>
          )}
        </div>

        <div className="weights">
          {CRITERIA.map((criterion) => (
            <div className="weight-row" key={criterion.key}>
              <div className="weight-head">
                <span className="weight-name">{criterion.label}</span>
                <span className="weight-value num">{shown[criterion.key]} %</span>
              </div>
              <input
                className="weight-slider"
                type="range"
                min={0}
                max={100}
                step={1}
                value={Math.round(project.weights[criterion.key])}
                aria-label={`Poids du critère ${criterion.label}`}
                onChange={(e) => setWeight(criterion.key, Number(e.target.value))}
              />
              <p className="weight-hint">{criterion.hint}</p>
            </div>
          ))}
        </div>

        <p className="note">
          La somme pondérée est compensatoire : une marge de sécurité faible peut être rachetée
          par une VAN élevée. L'étape Résultat mesure à quel point le classement tient quand on
          remue ces poids.
        </p>
      </Panel>

      <StepNav>
        <Button onClick={() => goStep('alternatives')}>Retour aux alternatives</Button>
        <Button variant="primary" onClick={confirmWeights}>
          {project.weightsConfirmed ? 'Voir les calculs' : 'Valider les priorités'}
        </Button>
      </StepNav>
    </div>
  );
}
