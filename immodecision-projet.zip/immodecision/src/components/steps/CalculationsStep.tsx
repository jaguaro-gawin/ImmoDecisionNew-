/**
 * Étape 4 — le détail chiffré.
 *
 * Une recommandation qu'on ne peut pas ouvrir ne se défend pas devant un
 * comité. Cette étape expose la mécanique complète d'une alternative :
 * échéancier, loyers indexés, fiscalité, flux, DSCR année par année.
 */

import { useApp, useCurrentProject, useDerived } from '../../store/useApp';
import { Panel, Button, Badge, Stat, StepNav, EmptyState } from '../ui/Panel';
import { DscrChart, CashflowChart } from '../charts/Charts';
import { downloadCsv, toCsv } from '../../lib/csv';
import {
  amount, money, percent, points, ratio, resistance, years,
} from '../../lib/format';
import type { Analysis, Project } from '../../core/types';

export function CalculationsStep() {
  const project = useCurrentProject() as Project;
  const { analyses } = useDerived();
  const { focusId, focusAlternative, goStep } = useApp();

  if (!analyses.length) {
    return (
      <div className="step">
        <EmptyState
          title="Aucune alternative calculable"
          body="Corrigez les valeurs signalées à l'étape Alternatives pour voir apparaître la projection."
          action={<Button variant="primary" onClick={() => goStep('alternatives')}>Revenir aux alternatives</Button>}
        />
      </div>
    );
  }

  const selected = analyses.find((a) => a.id === focusId) ?? analyses[0]!;
  const threshold = project.settings.dscrThreshold;

  return (
    <div className="step">
      <Panel
        title="Projection détaillée"
        caption="Choisissez une alternative pour ouvrir sa mécanique complète."
        actions={<Button onClick={() => exportProjection(selected, project)}>Exporter en CSV</Button>}
      >
        <div className="tabs" role="tablist">
          {analyses.map((a) => (
            <button
              key={a.id}
              type="button"
              role="tab"
              aria-selected={a.id === selected.id}
              className={`tab${a.id === selected.id ? ' tab-active' : ''}`}
              onClick={() => focusAlternative(a.id)}
            >
              <span className="tab-name">{a.name}</span>
              {a.feasible ? <Badge tone="ok">Finançable</Badge> : <Badge tone="refused">Refusée</Badge>}
            </button>
          ))}
        </div>

        <div className="stat-row">
          <Stat label="Fonds propres engagés" value={money(selected.equity)} />
          <Stat label="Montant emprunté" value={selected.hasDebt ? money(selected.principal) : 'Comptant'} />
          <Stat label="Échéance annuelle" value={selected.hasDebt ? money(selected.annuity) : '—'} />
          <Stat label="Intérêts payés" value={money(selected.interestPaid)} />
          <Stat
            label="VAN"
            value={money(selected.npv)}
            tone={selected.npv >= 0 ? 'ok' : 'refused'}
            note={`à ${percent(project.settings.discountRate, 1)}`}
          />
          <Stat
            label="TRI"
            value={selected.irr === null ? 'Indéterminé' : percent(selected.irr)}
            {...(selected.irrStatus === 'multiple' ? { note: 'plusieurs racines' } : {})}
          />
          <Stat
            label="Effet de levier"
            value={selected.leverage === null ? '—' : points(selected.leverage)}
            {...(selected.unleveredIrr === null ? {} : { note: `comptant ${percent(selected.unleveredIrr)}` })}
          />
          <Stat label="Récupération actualisée" value={years(selected.payback)} />
        </div>

        {selected.irrStatus !== 'ok' && (
          <p className="note note-warn">
            {selected.irrStatus === 'none'
              ? "Aucun TRI sur l'intervalle exploré : avec un apport très faible, la série de flux n'a pas de racine. La VAN reste le repère fiable."
              : `La série de flux change ${selected.signChanges} fois de signe : plusieurs TRI existent, l'indicateur perd son sens. Fiez-vous à la VAN.`}
          </p>
        )}
      </Panel>

      <div className="charts">
        <Panel
          title="Couverture de l'échéance"
          caption={`DSCR année par année. L'année ${selected.weakestYear ?? '—'} décide de la faisabilité.`}
        >
          <DscrChart analysis={selected} threshold={threshold} />
          <div className="stat-row stat-row-compact">
            <Stat label="DSCR minimum" value={selected.hasDebt ? ratio(selected.dscrMin) : '—'} />
            <Stat label="Marge de résistance" value={resistance(selected.resistance)} />
          </div>
        </Panel>

        <Panel
          title="Flux investisseur"
          caption="Apport en année 0, loyers nets pendant la détention, revente au terme."
        >
          <CashflowChart analysis={selected} />
          <div className="stat-row stat-row-compact">
            <Stat label="Capital restant dû au terme" value={money(selected.finalBalance)} />
            <Stat label="Flux de sortie" value={money(selected.exitFlow)} />
          </div>
        </Panel>
      </div>

      <Panel
        title="Année par année"
        caption="Loyer et charges progressent à leur propre rythme : n'indexer que les loyers rendrait le modèle optimiste par construction."
      >
        <div className="table-scroll">
          <table className="table table-dense">
            <thead>
              <tr>
                <th>An</th>
                <th className="right">Loyer encaissé</th>
                <th className="right">Charges</th>
                <th className="right">Loyer net</th>
                <th className="right">Intérêts</th>
                <th className="right">Capital</th>
                <th className="right">Échéance</th>
                <th className="right">Impôt</th>
                <th className="right">Flux net</th>
                <th className="right">CRD</th>
                <th className="right">DSCR</th>
              </tr>
            </thead>
            <tbody>
              {selected.years.map((y) => (
                <tr key={y.year} className={y.dscr !== null && y.dscr < threshold ? 'row-break' : undefined}>
                  <td>{y.year}</td>
                  <td className="right num">{amount(y.grossRent)}</td>
                  <td className="right num">{amount(y.charges)}</td>
                  <td className="right num">{amount(y.noi)}</td>
                  <td className="right num">{amount(y.interest)}</td>
                  <td className="right num">{amount(y.amortised)}</td>
                  <td className="right num">{amount(y.debtService)}</td>
                  <td className="right num">{amount(y.tax)}</td>
                  <td className={`right num${y.netCashflow < 0 ? ' tone-refused' : ''}`}>{amount(y.netCashflow)}</td>
                  <td className="right num">{amount(y.balance)}</td>
                  <td className={`right num${y.dscr !== null && y.dscr < threshold ? ' tone-refused' : ''}`}>
                    {y.dscr === null ? '—' : ratio(y.dscr)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="table-note">
          {`Montants en euros. Le DSCR rapporte le loyer net à l'échéance, avant impôt — c'est la lecture du prêteur. Seuil exigé : ${threshold.toFixed(2)}.`}
        </p>
      </Panel>

      <StepNav>
        <Button onClick={() => goStep('priorities')}>Retour aux priorités</Button>
        <Button variant="primary" onClick={() => goStep('results')}>Voir le résultat</Button>
      </StepNav>
    </div>
  );
}

/** Export CSV de la projection : ce que l'analyste rouvrira dans son tableur. */
function exportProjection(analysis: Analysis, project: Project): void {
  const rows: (string | number | null)[][] = [
    ['Projet', project.name],
    ['Alternative', analysis.name],
    ['Horizon (ans)', project.settings.horizonYears],
    ['Taux d actualisation (%)', project.settings.discountRate],
    ['Seuil DSCR', project.settings.dscrThreshold],
    ['Fonds propres', Math.round(analysis.equity)],
    ['Montant emprunte', Math.round(analysis.principal)],
    ['VAN', Math.round(analysis.npv)],
    ['TRI (%)', analysis.irr === null ? 'indetermine' : Number(analysis.irr.toFixed(3))],
    [],
    ['Annee', 'Loyer encaisse', 'Charges', 'Loyer net', 'Interets', 'Capital amorti',
      'Echeance', 'Impot', 'Flux net', 'Capital restant du', 'DSCR'],
    ...analysis.years.map((y) => [
      y.year, y.grossRent, y.charges, y.noi, y.interest, y.amortised,
      y.debtService, y.tax, y.netCashflow, y.balance, y.dscr,
    ]),
  ];

  const slug = `${project.name}-${analysis.name}`.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  downloadCsv(`immodecision-${slug}.csv`, toCsv(rows));
}
