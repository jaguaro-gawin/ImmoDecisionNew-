/**
 * Étape 2 — les couples (bien, financement).
 *
 * Chaque carte affiche en continu ce que la saisie produit : échéance, DSCR
 * minimum, VAN, verdict bancaire. L'effet d'un point de taux ou de dix mille
 * euros d'apport se lit sans changer d'écran.
 */

import { useApp, useCurrentProject, useDerived } from '../../store/useApp';
import { Panel, Button, Badge, StepNav } from '../ui/Panel';
import { NumberField, TextField, IssueList } from '../ui/Field';
import { ALTERNATIVE_FIELDS, FIELD_GROUPS } from '../../core/model';
import { money, percent, ratio } from '../../lib/format';
import type { Alternative, Analysis, Issue, Project } from '../../core/types';

export function AlternativesStep() {
  const project = useCurrentProject() as Project;
  const { analyses, issues } = useDerived();
  const { addAlternative, goStep } = useApp();

  return (
    <div className="step">
      <Panel
        title="Alternatives"
        caption="Une alternative n'est pas un bien, c'est un bien financé d'une certaine manière. Le même appartement à 40 % ou 50 % d'apport compte pour deux."
        actions={<Button variant="primary" onClick={addAlternative}>Ajouter une alternative</Button>}
      >
        <div className="alt-list">
          {project.alternatives.map((alt, index) => (
            <AlternativeCard
              key={alt.id}
              alternative={alt}
              index={index}
              analysis={analyses.find((a) => a.id === alt.id)}
              issues={issues.get(alt.id) ?? []}
              project={project}
            />
          ))}
        </div>
      </Panel>

      <StepNav>
        <Button onClick={() => goStep('settings')}>Retour aux hypothèses</Button>
        <Button variant="primary" onClick={() => goStep('priorities')}>Définir les priorités</Button>
      </StepNav>
    </div>
  );
}

function AlternativeCard({ alternative, index, analysis, issues, project }: {
  alternative: Alternative;
  index: number;
  analysis: Analysis | undefined;
  issues: Issue[];
  project: Project;
}) {
  const { updateAlternative, duplicateAlternative, removeAlternative } = useApp();
  const blocked = issues.some((issue) => issue.level === 'error');
  const only = project.alternatives.length <= 1;

  return (
    <article className={`alt-card${analysis && !analysis.feasible ? ' alt-refused' : ''}`}>
      <header className="alt-head">
        <span className="alt-index num">{String(index + 1).padStart(2, '0')}</span>
        <TextField
          label="Intitulé"
          value={alternative.name}
          onChange={(name) => updateAlternative(alternative.id, { name })}
        />
        <div className="alt-tools">
          <Button onClick={() => duplicateAlternative(alternative.id)}>Dupliquer</Button>
          <Button
            variant="danger"
            disabled={only}
            title={only ? 'Un projet garde au moins une alternative.' : undefined}
            onClick={() => removeAlternative(alternative.id)}
          >
            Retirer
          </Button>
        </div>
      </header>

      <div className="alt-fields">
        {FIELD_GROUPS.map((group) => (
          <fieldset className="field-group" key={group.key}>
            <legend className="field-group-label">{group.label}</legend>
            <div className="grid grid-auto">
              {ALTERNATIVE_FIELDS.filter((field) => field.group === group.key).map((field) => (
                <NumberField
                  key={field.key}
                  label={field.label}
                  unit={field.unit}
                  value={alternative[field.key]}
                  issue={issues.find((issue) => issue.field === field.key)}
                  onChange={(value) => updateAlternative(alternative.id, { [field.key]: value })}
                  id={`${alternative.id}-${field.key}`}
                />
              ))}
            </div>
          </fieldset>
        ))}
      </div>

      <IssueList issues={issues} />

      {blocked ? (
        <p className="alt-blocked">Alternative exclue des calculs tant qu'une valeur reste illisible.</p>
      ) : analysis ? (
        <SummaryStrip analysis={analysis} threshold={project.settings.dscrThreshold} />
      ) : null}
    </article>
  );
}

function SummaryStrip({ analysis, threshold }: { analysis: Analysis; threshold: number }) {
  const items: [string, string][] = [
    ['Coût total', money(analysis.totalCost)],
    ['Emprunt', analysis.hasDebt ? money(analysis.principal) : 'Comptant'],
    ['Échéance', analysis.hasDebt ? money(analysis.annuity) : '—'],
    ['DSCR min.', analysis.hasDebt ? ratio(analysis.dscrMin) : '—'],
    ['VAN', money(analysis.npv)],
    ['TRI', analysis.irr === null ? 'Indéterminé' : percent(analysis.irr)],
  ];

  return (
    <div className="alt-summary">
      <div className="alt-summary-items">
        {items.map(([label, value]) => (
          <div className="mini-stat" key={label}>
            <span className="mini-label">{label}</span>
            <span className="mini-value num">{value}</span>
          </div>
        ))}
      </div>
      <div className="alt-verdict">
        {analysis.feasible
          ? <Badge tone="ok">Finançable</Badge>
          : <Badge tone="refused">{`Refusée — DSCR ${ratio(analysis.dscrMin)} en an ${analysis.weakestYear}`}</Badge>}
        {analysis.hasDebt && (
          <span className="alt-verdict-note">
            {`Seuil exigé ${threshold.toFixed(2)} · LTV ${percent(analysis.loanToValue, 0)}`}
          </span>
        )}
      </div>
    </div>
  );
}
