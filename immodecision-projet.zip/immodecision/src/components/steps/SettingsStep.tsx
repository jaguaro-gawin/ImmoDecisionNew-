/**
 * Étape 1 — hypothèses communes.
 *
 * Horizon et taux d'actualisation sont au niveau du projet, non de
 * l'alternative : comparer des VAN calculées sur des durées ou des coûts
 * d'opportunité différents reviendrait à comparer deux échelles.
 */

import { useApp, useCurrentProject, useDerived } from '../../store/useApp';
import { Panel, Button, StepNav } from '../ui/Panel';
import { NumberField, TextField, SelectField, Switch, IssueList } from '../ui/Field';
import { SOCIAL_RATE, TAX_REGIMES } from '../../core/model';
import type { Project, TaxRegime } from '../../core/types';

const REGIME_OPTIONS = (Object.entries(TAX_REGIMES) as [TaxRegime, { label: string }][])
  .map(([value, def]) => ({ value, label: def.label }));

export function SettingsStep() {
  const project = useCurrentProject() as Project;
  const { settingsIssues } = useDerived();
  const { renameProject, updateSettings, goStep } = useApp();

  const issueFor = (field: string) => settingsIssues.find((i) => i.field === field);
  const s = project.settings;

  return (
    <div className="step">
      <Panel
        title="Cadre de l'analyse"
        caption="Ces hypothèses s'appliquent à toutes les alternatives du projet, pour qu'elles restent comparables."
      >
        <div className="grid grid-2">
          <TextField label="Nom du projet" value={project.name} onChange={renameProject} id="project-name" />
          <NumberField
            label="Horizon de détention"
            unit="ans"
            value={s.horizonYears}
            issue={issueFor('horizonYears')}
            hint="Durée au terme de laquelle le bien est supposé revendu."
            onChange={(horizonYears) => updateSettings({ horizonYears })}
            id="horizon"
          />
          <NumberField
            label="Taux d'actualisation"
            unit="%"
            value={s.discountRate}
            issue={issueFor('discountRate')}
            hint="Coût d'opportunité de l'investisseur : le rendement auquel il renonce ailleurs."
            onChange={(discountRate) => updateSettings({ discountRate })}
            id="discount"
          />
          <NumberField
            label="Seuil DSCR exigé"
            unit="ratio"
            value={s.dscrThreshold}
            issue={issueFor('dscrThreshold')}
            hint="Une alternative doit rester au-dessus chaque année, sans exception, pour être finançable."
            onChange={(dscrThreshold) => updateSettings({ dscrThreshold })}
            id="dscr"
          />
        </div>
        <IssueList issues={settingsIssues} />
      </Panel>

      <Panel
        title="Fiscalité"
        caption="Location nue, détenue par un particulier. Les régimes LMNP et les dispositifs de défiscalisation ne sont pas modélisés."
      >
        <div className="grid grid-3">
          <SelectField
            label="Régime des revenus fonciers"
            value={s.taxRegime}
            options={REGIME_OPTIONS}
            hint={TAX_REGIMES[s.taxRegime].hint}
            onChange={(taxRegime) => updateSettings({ taxRegime })}
          />
          {s.taxRegime !== 'none' && (
            <NumberField
              label="Tranche marginale d'imposition"
              unit="%"
              value={s.marginalTaxRate}
              onChange={(marginalTaxRate) => updateSettings({ marginalTaxRate })}
            />
          )}
          {s.taxRegime !== 'none' && (
            <NumberField
              label="Prélèvements sociaux"
              unit="%"
              value={s.socialRate}
              hint={`Taux en vigueur : ${SOCIAL_RATE} %.`}
              onChange={(socialRate) => updateSettings({ socialRate })}
            />
          )}
        </div>
        <Switch
          label="Imposer la plus-value de cession"
          hint="Abattements pour durée de détention : exonération d'impôt sur le revenu à 22 ans, de prélèvements sociaux à 30 ans."
          checked={s.taxCapitalGain}
          onChange={(taxCapitalGain) => updateSettings({ taxCapitalGain })}
        />
      </Panel>

      <StepNav>
        <Button variant="primary" onClick={() => goStep('alternatives')}>
          Passer aux alternatives
        </Button>
      </StepNav>
    </div>
  );
}
