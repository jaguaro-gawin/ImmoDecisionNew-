/**
 * Étape 5 — le résultat.
 *
 * Trois choses y sont dites, dans cet ordre : quelle alternative sort en tête,
 * pourquoi, et à quel point cette réponse tient si l'on change d'avis sur les
 * poids ou si le marché se retourne.
 */

import { useApp, useCurrentProject, useDerived, useRobustness } from '../../store/useApp';
import { Panel, Button, Stat, StepNav, EmptyState, Badge } from '../ui/Panel';
import { DecisionPlane, StabilityBars } from '../charts/Charts';
import { CRITERIA, displayWeights } from '../../core/model';
import { downloadCsv, toCsv } from '../../lib/csv';
import { money, percent, ratio, resistance, score as fmtScore } from '../../lib/format';
import type { Analysis, Project, RankedEntry } from '../../core/types';
import type { Robustness } from '../../store/useApp';
import type { StabilityEntry } from '../../core/robustness';

export function ResultsStep() {
  const project = useCurrentProject() as Project;
  const { analyses, ranking } = useDerived();
  const robustness = useRobustness();
  const { goStep } = useApp();

  if (!project.weightsConfirmed) {
    return (
      <div className="step">
        <EmptyState
          title="Fixez d'abord vos priorités"
          body="Le classement s'affiche une fois les poids validés. Les régler après coup reviendrait à choisir le gagnant, puis la règle qui le fait gagner."
          action={<Button variant="primary" onClick={() => goStep('priorities')}>Aller aux priorités</Button>}
        />
      </div>
    );
  }

  const { ranked, excluded } = ranking;

  if (!ranked.length) {
    return (
      <div className="step">
        <EmptyState
          title="Aucune alternative finançable"
          body={`Toutes les alternatives passent sous le seuil DSCR de ${project.settings.dscrThreshold.toFixed(2)} au moins une année. Augmentez l'apport, allongez la durée du prêt, ou révisez le seuil exigé.`}
          action={<Button variant="primary" onClick={() => goStep('alternatives')}>Revoir les alternatives</Button>}
        />
        {excluded.length > 0 && <ExcludedPanel excluded={excluded} project={project} />}
      </div>
    );
  }

  const leader = ranked[0]!;
  const leaderStability = robustness?.stability?.entries.find((e) => e.id === leader.analysis.id);

  return (
    <div className="step">
      <Verdict leader={leader} runnerUp={ranked[1]} stability={leaderStability} />

      <Panel
        title="Plan de décision"
        caption={`Rentabilité en ordonnée, résistance en abscisse. À gauche du mur, le DSCR passe sous ${project.settings.dscrThreshold.toFixed(2)} : la banque ne suit pas.`}
      >
        <DecisionPlane analyses={analyses} leaderId={leader.analysis.id} />
      </Panel>

      <RankingPanel ranked={ranked} project={project} />
      {robustness && <RobustnessPanel robustness={robustness} leader={leader} project={project} />}
      {robustness && <ScenarioPanel robustness={robustness} project={project} />}
      {excluded.length > 0 && <ExcludedPanel excluded={excluded} project={project} />}

      <StepNav>
        <Button onClick={() => goStep('calculations')}>Retour aux calculs</Button>
        <Button onClick={() => exportRanking(ranked, excluded, project)}>Exporter le classement</Button>
        <Button variant="primary" onClick={() => window.print()}>Imprimer la synthèse</Button>
      </StepNav>
    </div>
  );
}

/* ── Verdict ────────────────────────────────────────────────────────────── */

function Verdict({ leader, runnerUp, stability }: {
  leader: RankedEntry;
  runnerUp: RankedEntry | undefined;
  stability: StabilityEntry | undefined;
}) {
  const a = leader.analysis;

  const drivers = [...CRITERIA]
    .sort((x, y) => leader.contributions[y.key] - leader.contributions[x.key])
    .slice(0, 2)
    .map((c) => c.phrase);

  const confidence = stability
    ? stability.winRate >= 0.8 ? 'robuste' : stability.winRate >= 0.55 ? 'nuance' : 'fragile'
    : null;

  const share = stability ? (stability.winRate * 100).toFixed(0) : '';

  return (
    <section className="verdict">
      <div className="verdict-main">
        <span className="verdict-eyebrow">Alternative recommandée</span>
        <h2 className="verdict-name">{a.name}</h2>
        <p className="verdict-why">
          {runnerUp
            ? `Elle devance ${runnerUp.analysis.name} de ${fmtScore(leader.score - runnerUp.score)} point de score, portée surtout par ${drivers.join(' et ')}.`
            : "Seule alternative finançable du lot : le classement ne tranche rien, il constate."}
        </p>
        {confidence && (
          <p className={`verdict-confidence confidence-${confidence}`}>
            {confidence === 'robuste'
              ? `Classement robuste : elle reste première dans ${share} % des pondérations voisines.`
              : confidence === 'nuance'
                ? `Avance nuancée : elle ne tient la première place que dans ${share} % des pondérations voisines.`
                : `Résultat fragile : elle ne gagne que dans ${share} % des pondérations voisines. Le classement dépend surtout de vos poids.`}
          </p>
        )}
      </div>
      <div className="verdict-stats">
        <Stat label="Score pondéré" value={fmtScore(leader.score)} />
        <Stat label="VAN" value={money(a.npv)} tone={a.npv >= 0 ? 'ok' : 'refused'} />
        <Stat label="TRI" value={a.irr === null ? 'Indéterminé' : percent(a.irr)} />
        <Stat label="Marge de résistance" value={resistance(a.resistance)} />
      </div>
    </section>
  );
}

/* ── Classement ─────────────────────────────────────────────────────────── */

function RankingPanel({ ranked, project }: { ranked: RankedEntry[]; project: Project }) {
  const shown = displayWeights(project.weights);

  return (
    <Panel
      title="Classement"
      caption={`Pondération retenue : ${CRITERIA.map((c) => `${c.label} ${shown[c.key]} %`).join(' · ')}.`}
    >
      <div className="table-scroll">
        <table className="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Alternative</th>
              <th className="right">VAN</th>
              <th className="right">TRI</th>
              <th className="right">Rdt net</th>
              <th className="right">DSCR min.</th>
              <th className="right">Résistance</th>
              <th className="right">Score</th>
            </tr>
          </thead>
          <tbody>
            {ranked.map((entry) => {
              const a = entry.analysis;
              return (
                <tr key={a.id} className={entry.position === 1 ? 'row-leader' : undefined}>
                  <td>{entry.position}</td>
                  <td>
                    <span className="rank-name">{a.name}</span>
                    <div className="contrib">
                      {CRITERIA.map((c) => (
                        <span
                          key={c.key}
                          className={`contrib-seg contrib-${c.key}`}
                          style={{ flex: Math.max(entry.contributions[c.key], 0.001) }}
                          title={`${c.label} : ${fmtScore(entry.contributions[c.key])} sur ${fmtScore(entry.score)}`}
                        />
                      ))}
                    </div>
                  </td>
                  <td className="right num">{money(a.npv)}</td>
                  <td className="right num">{a.irr === null ? 'Indét.' : percent(a.irr)}</td>
                  <td className="right num">{percent(a.netYield)}</td>
                  <td className="right num">{a.hasDebt ? ratio(a.dscrMin) : 'Comptant'}</td>
                  <td className="right num">{resistance(a.resistance)}</td>
                  <td className={`right num${entry.position === 1 ? ' tone-leader' : ''}`}>
                    {fmtScore(entry.score)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="table-note">
        La barre sous chaque intitulé décompose le score par critère. Les valeurs sont normalisées
        sur le lot : ajouter ou retirer une alternative déplace les bornes et peut modifier les écarts.
      </p>
    </Panel>
  );
}

/* ── Robustesse ─────────────────────────────────────────────────────────── */

function RobustnessPanel({ robustness, leader, project }: {
  robustness: Robustness;
  leader: RankedEntry;
  project: Project;
}) {
  const { stability, tipping } = robustness;
  const shown = displayWeights(project.weights);

  // Un point de bascule à 0 ou 100 % de poids revient à supprimer un critère :
  // l'information n'aide personne.
  const meaningful = tipping.filter((t) => t.tipping !== null && t.tipping > 0 && t.tipping < 100);

  return (
    <Panel
      title="Robustesse du classement"
      caption={`Le score dépend de poids que personne ne connaît exactement. ${stability?.samples ?? 0} pondérations tirées à ±${stability?.spread ?? 0} points autour du réglage retenu.`}
    >
      {stability && <StabilityBars entries={stability.entries} />}
      <p className="table-note">Fréquence à laquelle chaque alternative sort première.</p>

      {meaningful.length ? (
        <div className="tipping">
          <h3 className="sub">Points de bascule</h3>
          <ul className="tipping-list">
            {meaningful.map((t) => {
              const criterion = CRITERIA.find((c) => c.key === t.key)!;
              const direction = t.tipping! > shown[t.key] ? 'au-delà de' : 'en deçà de';
              return (
                <li key={t.key}>
                  <span className="tipping-key">{criterion.label}</span>
                  <span className="tipping-text">
                    {`${direction} ${t.tipping} % de poids — contre ${shown[t.key]} % aujourd'hui — ${t.newLeader} passe devant.`}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      ) : (
        <p className="note">
          {`Aucun poids ne fait basculer le classement : ${leader.analysis.name} reste première sur toute la plage de pondérations testée.`}
        </p>
      )}
    </Panel>
  );
}

/* ── Scénarios ──────────────────────────────────────────────────────────── */

function ScenarioPanel({ robustness, project }: { robustness: Robustness; project: Project }) {
  const base = robustness.scenarios.find((s) => s.shock === 'base');
  if (!base) return null;

  return (
    <Panel
      title="Résistance aux chocs"
      caption="Une hypothèse dégradée à la fois. Une case rouge signale une alternative qui cesse d'être finançable."
    >
      <div className="table-scroll">
        <table className="table">
          <thead>
            <tr>
              <th>Scénario</th>
              {base.results.map((r) => <th className="right" key={r.id}>{r.name}</th>)}
            </tr>
          </thead>
          <tbody>
            {robustness.scenarios.map((scenario) => (
              <tr key={scenario.shock} className={scenario.shock === 'base' ? 'row-base' : undefined}>
                <td>{scenario.label}</td>
                {scenario.results.map((r) => (
                  <td className={`right num${r.feasible ? '' : ' tone-refused'}`} key={r.id}>
                    <span>{money(r.npv)}</span>
                    <span className="cell-sub">
                      {r.dscrMin === null ? 'comptant' : `DSCR ${ratio(r.dscrMin)}`}
                    </span>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="table-note">
        {`VAN et DSCR minimum sous chaque choc, seuil exigé ${project.settings.dscrThreshold.toFixed(2)}. Les chocs ne sont pas cumulés.`}
      </p>
    </Panel>
  );
}

/* ── Écartées ───────────────────────────────────────────────────────────── */

function ExcludedPanel({ excluded, project }: { excluded: Analysis[]; project: Project }) {
  return (
    <Panel
      title="Écartées par la banque"
      caption="Ces montages restent visibles : savoir pourquoi une piste tombe vaut mieux que de la voir disparaître."
    >
      <ul className="excluded">
        {excluded.map((a) => (
          <li className="excluded-item" key={a.id}>
            <div>
              <span className="excluded-name">{a.name}</span>
              <span className="excluded-reason">
                {`DSCR ${ratio(a.dscrMin)} en année ${a.weakestYear}, sous le seuil de ${project.settings.dscrThreshold.toFixed(2)}.`}
              </span>
            </div>
            <Badge tone="refused">
              {`Il manque ${percent((project.settings.dscrThreshold / (a.dscrMin ?? 1) - 1) * 100, 1)} de loyer net`}
            </Badge>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

/* ── Export ─────────────────────────────────────────────────────────────── */

function exportRanking(ranked: RankedEntry[], excluded: Analysis[], project: Project): void {
  const shown = displayWeights(project.weights);

  const rows: (string | number | null)[][] = [
    ['Projet', project.name],
    ['Horizon (ans)', project.settings.horizonYears],
    ['Taux d actualisation (%)', project.settings.discountRate],
    ['Seuil DSCR', project.settings.dscrThreshold],
    ['Ponderation', CRITERIA.map((c) => `${c.label} ${shown[c.key]}%`).join(' ')],
    [],
    ['Rang', 'Alternative', 'VAN', 'TRI (%)', 'Rendement net (%)', 'DSCR min',
      'Marge de resistance (%)', 'Score', 'Statut'],
    ...ranked.map((e) => [
      e.position, e.analysis.name, Math.round(e.analysis.npv),
      e.analysis.irr === null ? 'indetermine' : Number(e.analysis.irr.toFixed(3)),
      Number(e.analysis.netYield.toFixed(3)),
      e.analysis.dscrMin === null ? 'comptant' : Number(e.analysis.dscrMin.toFixed(3)),
      e.analysis.resistance === null ? null : Number((e.analysis.resistance * 100).toFixed(1)),
      Number(e.score.toFixed(4)), 'Financable',
    ]),
    ...excluded.map((a) => [
      null, a.name, Math.round(a.npv),
      a.irr === null ? 'indetermine' : Number(a.irr.toFixed(3)),
      Number(a.netYield.toFixed(3)),
      a.dscrMin === null ? null : Number(a.dscrMin.toFixed(3)),
      a.resistance === null ? null : Number((a.resistance * 100).toFixed(1)),
      null, 'Ecartee - DSCR sous le seuil',
    ]),
  ];

  const slug = project.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  downloadCsv(`immodecision-classement-${slug}.csv`, toCsv(rows));
}
