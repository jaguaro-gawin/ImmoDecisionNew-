/** Liste des projets. Un projet = une analyse indépendante. */

import { useApp } from '../store/useApp';
import { Button, EmptyState } from './ui/Panel';
import { date } from '../lib/format';

export function ProjectList() {
  const projects = useApp((s) => s.projects);
  const { createProject, openProject, duplicateProject, deleteProject } = useApp();

  return (
    <div className="projects">
      <header className="projects-head">
        <div>
          <h1 className="projects-title">Projets</h1>
          <p className="projects-sub">
            {projects.length
              ? `${projects.length} analyse${projects.length > 1 ? 's' : ''} enregistrée${projects.length > 1 ? 's' : ''} sur ce poste.`
              : "Chaque projet compare un lot d'alternatives sous ses propres hypothèses."}
          </p>
        </div>
        <Button variant="primary" onClick={() => createProject()}>Nouveau projet</Button>
      </header>

      {projects.length === 0 ? (
        <EmptyState
          title="Commencez par un projet"
          body="Un projet réunit les hypothèses de marché, les alternatives à comparer et la pondération retenue. Trois alternatives de départ sont créées pour vous."
          action={<Button variant="primary" onClick={() => createProject()}>Créer le premier projet</Button>}
        />
      ) : (
        <ul className="project-grid">
          {projects.map((project) => (
            <li className="project-card" key={project.id}>
              <button type="button" className="project-open" onClick={() => openProject(project.id)}>
                <span className="project-name">{project.name}</span>
                <span className="project-meta">
                  {`${project.alternatives.length} alternative${project.alternatives.length > 1 ? 's' : ''} · horizon ${project.settings.horizonYears} ans · seuil ${project.settings.dscrThreshold.toFixed(2)}`}
                </span>
                <span className="project-date">{`Créé le ${date(project.createdAt)}`}</span>
              </button>
              <div className="project-tools">
                <Button onClick={() => duplicateProject(project.id)}>Dupliquer</Button>
                <Button
                  variant="danger"
                  onClick={() => {
                    if (window.confirm(`Supprimer « ${project.name} » ? Cette action est définitive.`)) {
                      deleteProject(project.id);
                    }
                  }}
                >
                  Supprimer
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
