/**
 * Coquille applicative — barre, rail d'étapes et vue courante.
 * Aucune logique métier ici : l'aiguillage, rien d'autre.
 */

import type { ReactElement } from 'react';

import { STEPS, useApp, useCurrentProject, useDerived } from '../store/useApp';
import type { StepKey } from '../store/useApp';
import { Button } from './ui/Panel';
import { ProjectList } from './ProjectList';
import { SettingsStep } from './steps/SettingsStep';
import { AlternativesStep } from './steps/AlternativesStep';
import { PrioritiesStep } from './steps/PrioritiesStep';
import { CalculationsStep } from './steps/CalculationsStep';
import { ResultsStep } from './steps/ResultsStep';

const VIEWS: Record<StepKey, () => ReactElement> = {
  settings: SettingsStep,
  alternatives: AlternativesStep,
  priorities: PrioritiesStep,
  calculations: CalculationsStep,
  results: ResultsStep,
};

export function App() {
  const route = useApp((s) => s.route);
  const step = useApp((s) => s.step);
  const project = useCurrentProject();

  if (route === 'projects' || !project) {
    return (
      <div className="shell shell-plain">
        <TopBar />
        <main className="main"><ProjectList /></main>
      </div>
    );
  }

  const View = VIEWS[step];

  return (
    <div className="shell">
      <TopBar />
      <div className="layout">
        <Rail />
        <main className="main"><View /></main>
      </div>
    </div>
  );
}

function TopBar() {
  const route = useApp((s) => s.route);
  const go = useApp((s) => s.go);
  const project = useCurrentProject();

  return (
    <header className="topbar">
      <button type="button" className="wordmark" title="Revenir aux projets" onClick={() => go('projects')}>
        <span className="wordmark-mark">ID</span>
        <span className="wordmark-text">
          <strong>ImmoDécision</strong>
          <span>Aide à la décision d'investissement</span>
        </span>
      </button>

      {route === 'workspace' && project && (
        <div className="topbar-context">
          <span className="topbar-project">{project.name}</span>
          <span className="topbar-detail">
            {`${project.alternatives.length} alternatives · horizon ${project.settings.horizonYears} ans · seuil DSCR ${project.settings.dscrThreshold.toFixed(2)}`}
          </span>
        </div>
      )}

      <div className="topbar-actions">
        {route === 'workspace' && <Button onClick={() => go('projects')}>Tous les projets</Button>}
      </div>
    </header>
  );
}

function Rail() {
  const step = useApp((s) => s.step);
  const goStep = useApp((s) => s.goStep);
  const project = useCurrentProject();
  const { ranking, invalid } = useDerived();

  const status: Partial<Record<StepKey, string>> = {
    ...(invalid.length ? { alternatives: `${invalid.length} à corriger` } : {}),
    ...(project?.weightsConfirmed ? {} : { priorities: 'à valider' }),
    results: project?.weightsConfirmed
      ? `${ranking.ranked.length} classée${ranking.ranked.length > 1 ? 's' : ''}`
      : 'verrouillé',
  };

  return (
    <nav className="rail" aria-label="Étapes de l'analyse">
      <ol className="rail-steps">
        {STEPS.map((definition, index) => (
          <li key={definition.key}>
            <button
              type="button"
              className={`rail-step${step === definition.key ? ' rail-step-active' : ''}`}
              aria-current={step === definition.key ? 'step' : undefined}
              onClick={() => goStep(definition.key)}
            >
              <span className="rail-num num">{index + 1}</span>
              <span className="rail-body">
                <span className="rail-label">{definition.label}</span>
                <span className="rail-caption">{definition.caption}</span>
                {status[definition.key] && (
                  <span className="rail-status">{status[definition.key]}</span>
                )}
              </span>
            </button>
          </li>
        ))}
      </ol>
    </nav>
  );
}
