/**
 * Champs de saisie.
 *
 * `NumberField` garde un brouillon local tant qu'il a le focus. Sans lui, un
 * champ contrôlé réécrit la valeur à chaque frappe : taper « 4, » verrait la
 * virgule effacée — la valeur remontée valant déjà 4 — et le champ deviendrait
 * impossible à décimaliser. Le brouillon est relâché à la sortie du champ, où
 * la mise en forme (séparateurs de milliers) reprend la main.
 */

import { useState } from 'react';
import type { ChangeEvent, ReactNode } from 'react';
import { editable, parseNumber } from '../../lib/format';
import type { Issue } from '../../core/types';

interface NumberFieldProps {
  label: string;
  unit?: string;
  value: number;
  onChange: (value: number) => void;
  issue?: Issue | undefined;
  hint?: string;
  id?: string;
}

export function NumberField({ label, unit, value, onChange, issue, hint, id }: NumberFieldProps) {
  const [draft, setDraft] = useState<string | null>(null);

  const handleChange = (event: ChangeEvent<HTMLInputElement>): void => {
    setDraft(event.target.value);
    onChange(parseNumber(event.target.value));
  };

  return (
    <label className={`field${issue ? ` field-${issue.level}` : ''}`}>
      <span className="field-label">
        {label}
        {unit && <span className="field-unit">{unit}</span>}
      </span>
      <input
        className="field-input num"
        type="text"
        inputMode="decimal"
        data-field={id}
        value={draft ?? editable(value)}
        onChange={handleChange}
        onBlur={() => setDraft(null)}
      />
      {issue ? <span className="field-message">{issue.message}</span>
        : hint ? <span className="field-hint">{hint}</span> : null}
    </label>
  );
}

interface TextFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  id?: string;
}

export function TextField({ label, value, onChange, placeholder, id }: TextFieldProps) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      <input
        className="field-input"
        type="text"
        data-field={id}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

interface SelectFieldProps<T extends string> {
  label: string;
  value: T;
  options: readonly { value: T; label: string }[];
  onChange: (value: T) => void;
  hint?: string;
}

export function SelectField<T extends string>({
  label, value, options, onChange, hint,
}: SelectFieldProps<T>) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      <select
        className="field-input"
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
      {hint && <span className="field-hint">{hint}</span>}
    </label>
  );
}

export function Switch({ label, hint, checked, onChange }: {
  label: string;
  hint?: ReactNode;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label className="switch">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>
        <span className="switch-label">{label}</span>
        {hint && <span className="switch-hint">{hint}</span>}
      </span>
    </label>
  );
}

export function IssueList({ issues }: { issues: Issue[] }) {
  const warnings = issues.filter((issue) => issue.level === 'warning');
  if (!warnings.length) return null;
  return (
    <ul className="issues">
      {warnings.map((issue, index) => (
        <li className="issue" key={`${issue.field}-${index}`}>{issue.message}</li>
      ))}
    </ul>
  );
}
