/** Blocs de présentation : l'unité de composition de toutes les étapes. */

import type { ReactNode } from 'react';

export function Panel({ title, caption, actions, children }: {
  title?: string;
  caption?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="panel">
      {(title || actions) && (
        <header className="panel-head">
          <div>
            {title && <h2 className="panel-title">{title}</h2>}
            {caption && <p className="panel-caption">{caption}</p>}
          </div>
          {actions && <div className="panel-actions">{actions}</div>}
        </header>
      )}
      <div className="panel-body">{children}</div>
    </section>
  );
}

export function Stat({ label, value, tone, note }: {
  label: string;
  value: string;
  tone?: 'ok' | 'refused';
  note?: string;
}) {
  return (
    <div className={`stat${tone ? ` stat-${tone}` : ''}`}>
      <span className="stat-label">{label}</span>
      <span className="stat-value num">{value}</span>
      {note && <span className="stat-note">{note}</span>}
    </div>
  );
}

export function Badge({ children, tone = 'neutral' }: {
  children: ReactNode;
  tone?: 'neutral' | 'ok' | 'refused';
}) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function Button({ children, onClick, variant = 'quiet', disabled, title }: {
  children: ReactNode;
  onClick: () => void;
  variant?: 'quiet' | 'primary' | 'danger';
  disabled?: boolean;
  title?: string;
}) {
  return (
    <button
      type="button"
      className={`btn btn-${variant}`}
      onClick={onClick}
      disabled={disabled}
      title={title}
    >
      {children}
    </button>
  );
}

export function EmptyState({ title, body, action }: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty">
      <h3 className="empty-title">{title}</h3>
      <p className="empty-body">{body}</p>
      {action}
    </div>
  );
}

export function StepNav({ children }: { children: ReactNode }) {
  return <div className="step-nav">{children}</div>;
}
