/**
 * Robustesse du classement.
 *
 * Un score pondéré ne vaut que ce que valent ses poids, et personne ne connaît
 * les siens à cinq points près. Trois questions y répondent, sans jamais
 * demander à l'utilisateur d'imaginer un scénario :
 *  1. le gagnant tient-il si l'on remue les poids ? (stabilité)
 *  2. à partir de quel poids bascule-t-il ? (point de bascule)
 *  3. que devient-il si le marché se retourne ? (scénarios de choc)
 */

import { CRITERIA_KEYS, rebalanceWeights } from './model';
import { rank } from './scoring';
import { analyze } from './analyze';
import type { Alternative, Analysis, CriterionKey, Settings, Weights } from './types';

/** Générateur pseudo-aléatoire déterministe : un chiffre qui change d'un
 *  affichage à l'autre ne se présente pas devant un comité. */
function seeded(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface StabilityEntry {
  id: string;
  name: string;
  winRate: number;
  meanRank: number | null;
  bestRank: number | null;
  worstRank: number | null;
}

export interface StabilityResult {
  samples: number;
  spread: number;
  entries: StabilityEntry[];
}

/**
 * Fréquence à laquelle chaque alternative reste première quand on perturbe les
 * poids autour du réglage courant. `spread` est l'amplitude en points ; à 100,
 * le tirage couvre tout le simplexe des pondérations possibles.
 */
export function stability(
  analyses: Analysis[],
  weights: Weights,
  { samples = 2000, spread = 25, seed = 20240601 } = {},
): StabilityResult {
  const random = seeded(seed);
  const wins = new Map<string, number>();
  const positions = new Map<string, number[]>();
  analyses.forEach((a) => { wins.set(a.id, 0); positions.set(a.id, []); });

  let counted = 0;
  for (let i = 0; i < samples; i += 1) {
    const draw = {} as Weights;
    let sum = 0;
    CRITERIA_KEYS.forEach((key) => {
      const value = Math.max(0, weights[key] + (random() * 2 - 1) * spread);
      draw[key] = value;
      sum += value;
    });
    if (sum <= 0) continue;
    CRITERIA_KEYS.forEach((key) => { draw[key] = (draw[key] / sum) * 100; });

    const { ranked } = rank(analyses, draw);
    if (!ranked.length) continue;
    counted += 1;
    const leader = ranked[0]!.analysis.id;
    wins.set(leader, (wins.get(leader) ?? 0) + 1);
    ranked.forEach((entry, index) => positions.get(entry.analysis.id)!.push(index + 1));
  }

  const entries = analyses
    .map((a) => {
      const ranks = positions.get(a.id)!;
      return {
        id: a.id,
        name: a.name,
        winRate: counted ? (wins.get(a.id) ?? 0) / counted : 0,
        meanRank: ranks.length ? ranks.reduce((s, r) => s + r, 0) / ranks.length : null,
        bestRank: ranks.length ? Math.min(...ranks) : null,
        worstRank: ranks.length ? Math.max(...ranks) : null,
      };
    })
    .sort((a, b) => b.winRate - a.winRate);

  return { samples: counted, spread, entries };
}

export interface TippingPoint {
  key: CriterionKey;
  current: number;
  tipping: number | null;
  newLeader: string | null;
}

/** Poids à partir duquel le vainqueur change, critère par critère, les autres
 *  poids étant redistribués au prorata. */
export function tippingPoints(
  analyses: Analysis[],
  weights: Weights,
  step = 1,
): TippingPoint[] {
  const reference = rank(analyses, weights).ranked[0];
  if (!reference) return [];

  return CRITERIA_KEYS.map((key) => {
    let tipping: number | null = null;
    let newLeader: string | null = null;

    for (let w = 0; w <= 100; w += step) {
      const leader = rank(analyses, rebalanceWeights(weights, key, w)).ranked[0];
      if (leader && leader.analysis.id !== reference.analysis.id) {
        const distance = Math.abs(w - weights[key]);
        if (tipping === null || distance < Math.abs(tipping - weights[key])) {
          tipping = w;
          newLeader = leader.analysis.name;
        }
      }
    }
    return { key, current: weights[key], tipping, newLeader };
  });
}

/** Chocs appliqués aux hypothèses, un seul paramètre à la fois : une
 *  sensibilité lisible vaut mieux qu'un scénario composite. */
export const SHOCKS: readonly { key: string; label: string; apply: (a: Alternative) => Alternative }[] = [
  { key: 'base', label: 'Hypothèses centrales', apply: (a) => a },
  { key: 'rent', label: 'Loyer −10 %', apply: (a) => ({ ...a, monthlyRent: a.monthlyRent * 0.9 }) },
  { key: 'vacancy', label: 'Vacance +5 pts', apply: (a) => ({ ...a, vacancyRate: a.vacancyRate + 5 }) },
  { key: 'rate', label: 'Taux +1 pt', apply: (a) => ({ ...a, loanRate: a.loanRate + 1 }) },
  { key: 'charges', label: 'Charges +20 %', apply: (a) => ({ ...a, annualCharges: a.annualCharges * 1.2 }) },
  { key: 'resale', label: 'Revente −10 %', apply: (a) => ({ ...a, resaleValue: a.resaleValue * 0.9 }) },
];

export interface ScenarioResult {
  id: string;
  name: string;
  npv: number;
  irr: number | null;
  dscrMin: number | null;
  feasible: boolean;
}

export interface Scenario {
  shock: string;
  label: string;
  results: ScenarioResult[];
}

export function scenarios(alternatives: Alternative[], settings: Settings): Scenario[] {
  return SHOCKS.map((shock) => ({
    shock: shock.key,
    label: shock.label,
    results: alternatives.map((alt) => {
      const shocked = analyze(shock.apply(alt), settings);
      return {
        id: alt.id,
        name: alt.name,
        npv: shocked.npv,
        irr: shocked.irr,
        dscrMin: shocked.dscrMin,
        feasible: shocked.feasible,
      };
    }),
  }));
}
