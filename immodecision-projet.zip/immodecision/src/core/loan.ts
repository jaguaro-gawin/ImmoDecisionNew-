/** Échéancier de prêt à annuités constantes. Fonctions pures. */

export interface ScheduleRow {
  year: number;
  active: boolean;
  opening: number;
  interest: number;
  amortised: number;
  debtService: number;
  balance: number;
}

export interface Schedule {
  annuity: number;
  principal: number;
  rows: ScheduleRow[];
}

/**
 * Annuité constante : a = C · t / (1 − (1 + t)^−n)
 * @param principal montant emprunté, en euros
 * @param rate taux annuel en pourcentage
 * @param years durée en années
 */
export function annuity(principal: number, rate: number, years: number): number {
  if (principal <= 0 || years <= 0) return 0;
  const r = rate / 100;
  if (r === 0) return principal / years;
  return (principal * r) / (1 - Math.pow(1 + r, -years));
}

/**
 * Décompose le prêt année par année. Fournit les trois informations dont le
 * reste du modèle dépend : les intérêts de chaque année (déductibles au régime
 * réel), le service de la dette (dénominateur du DSCR) et le capital restant
 * dû à toute date (nécessaire en cas de revente avant la fin du prêt).
 */
export function schedule(
  loan: { principal: number; rate: number; years: number },
  horizon: number,
): Schedule {
  const payment = annuity(loan.principal, loan.rate, loan.years);
  const r = loan.rate / 100;
  const rows: ScheduleRow[] = [];
  let balance = loan.principal > 0 ? loan.principal : 0;

  for (let year = 1; year <= horizon; year += 1) {
    const active = year <= loan.years && loan.principal > 0;
    const opening = balance;
    const interest = active ? opening * r : 0;
    const amortised = active ? Math.min(payment - interest, opening) : 0;
    balance = active ? Math.max(opening - amortised, 0) : opening;

    rows.push({
      year,
      active,
      opening,
      interest,
      amortised,
      debtService: active ? payment : 0,
      balance,
    });
  }

  return { annuity: payment, principal: Math.max(loan.principal, 0), rows };
}

export const totalInterest = (rows: ScheduleRow[]): number =>
  rows.reduce((sum, row) => sum + row.interest, 0);
