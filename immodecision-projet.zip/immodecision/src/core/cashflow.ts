/**
 * Actualisation des flux : VAN et TRI.
 *
 * Le TRI n'a pas de forme close. Il est résolu numériquement, et le résultat
 * porte un statut explicite plutôt qu'une valeur silencieusement fausse.
 */

import type { IrrStatus } from './types';

/** VAN d'une séquence de flux, l'indice 0 valant t = 0. */
export function npv(cashflows: number[], rate: number): number {
  const r = rate / 100;
  return cashflows.reduce((sum, cf, t) => sum + cf / Math.pow(1 + r, t), 0);
}

const SCAN_LOW = -99;
const SCAN_HIGH = 300;
const SCAN_STEPS = 800;
const TOLERANCE = 1e-7;

function bisect(cashflows: number[], low: number, high: number): number {
  let a = low;
  let b = high;
  let fa = npv(cashflows, a);

  for (let i = 0; i < 80; i += 1) {
    const m = (a + b) / 2;
    const fm = npv(cashflows, m);
    if (Math.abs(fm) < TOLERANCE) return m;
    if (fa * fm <= 0) b = m;
    else { a = m; fa = fm; }
  }
  return (a + b) / 2;
}

export interface IrrResult {
  rate: number | null;
  status: IrrStatus;
  roots: number[];
}

/**
 * TRI, par balayage puis dichotomie sur [−99 %, +300 %].
 *  - `ok`       : racine unique ;
 *  - `multiple` : flux non conventionnels, l'indicateur perd son sens ;
 *  - `none`     : aucune racine — apport quasi nul, levier extrême. La VAN
 *                 reste alors le seul repère valide.
 */
export function irr(cashflows: number[]): IrrResult {
  const roots: number[] = [];
  let prevRate = SCAN_LOW;
  let prevValue = npv(cashflows, prevRate);

  if (Math.abs(prevValue) < TOLERANCE) roots.push(prevRate);

  for (let i = 1; i <= SCAN_STEPS; i += 1) {
    const rate = SCAN_LOW + ((SCAN_HIGH - SCAN_LOW) * i) / SCAN_STEPS;
    const value = npv(cashflows, rate);
    if (Math.abs(value) < TOLERANCE) roots.push(rate);
    else if (prevValue * value < 0) roots.push(bisect(cashflows, prevRate, rate));
    prevRate = rate;
    prevValue = value;
  }

  if (roots.length === 0) return { rate: null, status: 'none', roots };
  if (roots.length > 1) return { rate: roots[0]!, status: 'multiple', roots };
  return { rate: roots[0]!, status: 'ok', roots };
}

/** Au-delà d'un changement de signe, l'unicité du TRI n'est pas garantie. */
export function signChanges(cashflows: number[]): number {
  let changes = 0;
  let previous = 0;
  cashflows.forEach((cf) => {
    const sign = Math.sign(cf);
    if (sign === 0) return;
    if (previous !== 0 && sign !== previous) changes += 1;
    previous = sign;
  });
  return changes;
}

/** Délai de récupération actualisé, en années. `null` si jamais atteint. */
export function discountedPayback(cashflows: number[], rate: number): number | null {
  const r = rate / 100;
  let cumulative = 0;

  for (let t = 0; t < cashflows.length; t += 1) {
    const previous = cumulative;
    cumulative += cashflows[t]! / Math.pow(1 + r, t);
    if (previous < 0 && cumulative >= 0) {
      const step = cumulative - previous;
      return step === 0 ? t : t - 1 + Math.abs(previous) / step;
    }
  }
  return null;
}
