/**
 * Validation des saisies. Deux niveaux, jamais mélangés :
 *  - `error`   : le calcul n'a pas de sens, l'alternative est écartée du lot ;
 *  - `warning` : le calcul tient, mais une hypothèse mérite d'être regardée.
 * Chaque message dit ce qui ne va pas et ce qu'il faut faire.
 */

import { MICRO_CEILING } from './model';
import type { Alternative, Issue, IssueLevel, NumericField, Settings } from './types';

interface Rule {
  field: NumericField;
  test: (value: number) => boolean;
  level: IssueLevel;
  message: string;
}

const RULES: Rule[] = [
  { field: 'price', test: (v) => v > 0, level: 'error', message: 'Le prix du bien doit être supérieur à 0.' },
  { field: 'acquisitionFeeRate', test: (v) => v >= 0 && v <= 30, level: 'error', message: 'Les frais d\u2019acquisition se saisissent entre 0 et 30 %.' },
  { field: 'monthlyRent', test: (v) => v > 0, level: 'error', message: 'Le loyer mensuel doit être supérieur à 0.' },
  { field: 'vacancyRate', test: (v) => v >= 0 && v < 100, level: 'error', message: 'La vacance se saisit entre 0 et 99 %.' },
  { field: 'annualCharges', test: (v) => v >= 0, level: 'error', message: 'Les charges ne peuvent pas être négatives.' },
  { field: 'resaleValue', test: (v) => v >= 0, level: 'error', message: 'La valeur de revente ne peut pas être négative.' },
  { field: 'downPayment', test: (v) => v >= 0, level: 'error', message: 'L\u2019apport ne peut pas être négatif.' },
  { field: 'loanRate', test: (v) => v >= 0 && v <= 25, level: 'error', message: 'Le taux d\u2019emprunt se saisit entre 0 et 25 %.' },
  { field: 'loanYears', test: (v) => v >= 1 && v <= 40, level: 'error', message: 'La durée d\u2019emprunt se saisit entre 1 et 40 ans.' },
  { field: 'loanRate', test: (v) => v <= 15, level: 'warning', message: 'Taux inhabituellement élevé : vérifiez la saisie.' },
  { field: 'rentGrowth', test: (v) => v <= 10, level: 'warning', message: 'Croissance du loyer très optimiste au regard de l\u2019indexation réglementée.' },
];

export function validateAlternative(alt: Alternative, settings: Settings): Issue[] {
  const issues: Issue[] = [];

  RULES.forEach((rule) => {
    const value = alt[rule.field];
    if (!Number.isFinite(value)) {
      if (rule.level === 'error') {
        issues.push({ field: rule.field, level: 'error', message: 'Valeur manquante ou illisible.' });
      }
      return;
    }
    if (!rule.test(value)) issues.push({ field: rule.field, level: rule.level, message: rule.message });
  });

  const totalCost = alt.price * (1 + alt.acquisitionFeeRate / 100);
  if (Number.isFinite(alt.downPayment) && alt.downPayment > totalCost) {
    issues.push({
      field: 'downPayment',
      level: 'warning',
      message: 'Apport supérieur au coût total : l\u2019opération est traitée comme un achat comptant.',
    });
  }

  if (settings.taxRegime === 'micro' && alt.monthlyRent * 12 > MICRO_CEILING) {
    issues.push({
      field: 'monthlyRent',
      level: 'warning',
      message: `Recettes annuelles au-dessus de ${MICRO_CEILING.toLocaleString('fr-FR')} € : le micro-foncier n\u2019est plus ouvert, passez au régime réel.`,
    });
  }

  if (Number.isFinite(alt.resaleValue) && Number.isFinite(alt.price) && alt.resaleValue < alt.price) {
    issues.push({
      field: 'resaleValue',
      level: 'warning',
      message: 'Revente inférieure au prix d\u2019achat : hypothèse de moins-value.',
    });
  }

  return issues;
}

export function validateSettings(settings: Settings): Issue[] {
  const issues: Issue[] = [];

  if (!(settings.horizonYears >= 1 && settings.horizonYears <= 40)) {
    issues.push({ field: 'horizonYears', level: 'error', message: 'L\u2019horizon se saisit entre 1 et 40 ans.' });
  }
  if (!(settings.discountRate >= 0 && settings.discountRate <= 30)) {
    issues.push({ field: 'discountRate', level: 'error', message: 'Le taux d\u2019actualisation se saisit entre 0 et 30 %.' });
  }
  if (!(settings.dscrThreshold >= 0 && settings.dscrThreshold <= 5)) {
    issues.push({ field: 'dscrThreshold', level: 'error', message: 'Le seuil DSCR se saisit entre 0 et 5.' });
  }
  if (settings.dscrThreshold < 1) {
    issues.push({
      field: 'dscrThreshold',
      level: 'warning',
      message: 'Sous 1,0, le seuil accepte des montages dont le loyer ne couvre pas l\u2019échéance.',
    });
  }

  return issues;
}

export const hasBlockingError = (issues: Issue[]): boolean =>
  issues.some((issue) => issue.level === 'error');
