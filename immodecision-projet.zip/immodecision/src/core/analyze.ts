/**
 * Analyse d'une alternative — projection annuelle et indicateurs.
 *
 * Une alternative est un couple (bien, montage de financement). C'est l'unité
 * de décision : un même appartement financé à 40 % ou à 50 % d'apport donne
 * deux alternatives, parce que le financement change à la fois la rentabilité
 * perçue par l'investisseur et la faisabilité bancaire de l'opération.
 */

import { schedule, totalInterest } from './loan';
import { npv, irr, signChanges, discountedPayback } from './cashflow';
import { rentalTax, capitalGainTax } from './tax';
import type { Alternative, Analysis, ProjectionYear, Settings } from './types';

interface Projection {
  equity: number;
  principal: number;
  totalCost: number;
  acquisitionFees: number;
  annuity: number;
  interestPaid: number;
  years: ProjectionYear[];
  finalBalance: number;
  capitalGain: ReturnType<typeof capitalGainTax>;
  exitFlow: number;
  cashflows: number[];
}

function project(
  alt: Alternative,
  settings: Settings,
  { forceFullEquity = false } = {},
): Projection {
  const horizon = Math.max(1, Math.round(settings.horizonYears));
  const acquisitionFees = alt.price * (alt.acquisitionFeeRate / 100);
  const totalCost = alt.price + acquisitionFees;

  const equity = forceFullEquity ? totalCost : Math.min(Math.max(alt.downPayment, 0), totalCost);
  const principal = Math.max(totalCost - equity, 0);

  const loan = schedule(
    { principal, rate: alt.loanRate, years: Math.max(1, Math.round(alt.loanYears)) },
    horizon,
  );

  const rates = { marginalTaxRate: settings.marginalTaxRate, socialRate: settings.socialRate };
  const occupancy = 1 - Math.min(Math.max(alt.vacancyRate, 0), 100) / 100;

  const years: ProjectionYear[] = [];
  let carriedDeficit = 0;

  for (let t = 1; t <= horizon; t += 1) {
    const contractualRent = alt.monthlyRent * 12 * Math.pow(1 + alt.rentGrowth / 100, t - 1);
    const grossRent = contractualRent * occupancy;
    const charges = alt.annualCharges * Math.pow(1 + alt.chargesGrowth / 100, t - 1);
    const noi = grossRent - charges;

    const row = loan.rows[t - 1]!;
    const taxed = rentalTax(
      settings.taxRegime,
      { grossRent, charges, interest: row.interest },
      rates,
      carriedDeficit,
    );
    carriedDeficit = taxed.carriedDeficit;

    years.push({
      year: t,
      contractualRent,
      grossRent,
      charges,
      noi,
      interest: row.interest,
      amortised: row.amortised,
      debtService: row.debtService,
      balance: row.balance,
      tax: taxed.tax,
      taxBase: taxed.base,
      dscr: row.debtService > 0 ? noi / row.debtService : null,
      netCashflow: noi - row.debtService - taxed.tax,
    });
  }

  const finalBalance = years[years.length - 1]!.balance;
  const gain = settings.taxCapitalGain
    ? capitalGainTax(
      { resaleValue: alt.resaleValue, acquisitionCost: totalCost, holdingYears: horizon },
      rates,
    )
    : { tax: 0, gain: alt.resaleValue - totalCost, incomeTax: 0, socialTax: 0 };

  const exitFlow = alt.resaleValue - finalBalance - gain.tax;
  const cashflows = [-equity, ...years.map((y) => y.netCashflow)];
  cashflows[cashflows.length - 1] = cashflows[cashflows.length - 1]! + exitFlow;

  return {
    equity,
    principal,
    totalCost,
    acquisitionFees,
    annuity: loan.annuity,
    interestPaid: totalInterest(loan.rows),
    years,
    finalBalance,
    capitalGain: gain,
    exitFlow,
    cashflows,
  };
}

/** Analyse complète d'une alternative sous les hypothèses d'un projet. */
export function analyze(alt: Alternative, settings: Settings): Analysis {
  const base = project(alt, settings);
  const threshold = settings.dscrThreshold;

  const rateOfReturn = irr(base.cashflows);

  // Référence sans levier : le même bien payé comptant, hypothèses
  // d'exploitation inchangées. L'écart des deux TRI isole l'effet du crédit.
  const unlevered = irr(project(alt, settings, { forceFullEquity: true }).cashflows);

  const dscrSeries = base.years.filter((y) => y.dscr !== null);
  const hasDebt = dscrSeries.length > 0;
  const dscrMin = hasDebt ? Math.min(...dscrSeries.map((y) => y.dscr!)) : null;
  const weakestYear = hasDebt
    ? dscrSeries.reduce((a, b) => (b.dscr! < a.dscr! ? b : a)).year
    : null;

  // Marge de résistance : part du loyer net que l'alternative peut perdre,
  // dans son année la plus fragile, avant de rompre le seuil bancaire.
  let resistance: number | null = null;
  dscrSeries.forEach((y) => {
    if (y.noi <= 0) return;
    const margin = 1 - (threshold * y.debtService) / y.noi;
    resistance = resistance === null ? margin : Math.min(resistance, margin);
  });

  const firstYear = base.years[0]!;

  return {
    id: alt.id,
    name: alt.name,
    alternative: alt,
    ...base,
    npv: npv(base.cashflows, settings.discountRate),
    irr: rateOfReturn.rate,
    irrStatus: rateOfReturn.status,
    unleveredIrr: unlevered.rate,
    leverage:
      rateOfReturn.rate !== null && unlevered.rate !== null
        ? rateOfReturn.rate - unlevered.rate
        : null,
    signChanges: signChanges(base.cashflows),
    payback: discountedPayback(base.cashflows, settings.discountRate),
    hasDebt,
    dscrMin,
    weakestYear,
    // Marge de sécurité : écart, en points de ratio, entre le DSCR le plus bas
    // et le seuil exigé. Sans dette, aucun engagement ne peut être rompu.
    dscrMargin: hasDebt ? dscrMin! - threshold : null,
    resistance,
    netYield: (firstYear.noi / base.totalCost) * 100,
    grossYield: ((alt.monthlyRent * 12) / base.totalCost) * 100,
    feasible: hasDebt ? dscrMin! >= threshold : true,
    loanToValue: base.totalCost > 0 ? (base.principal / base.totalCost) * 100 : 0,
  };
}
