/**
 * Décision multicritère — normalisation min-max puis somme pondérée.
 *
 * Méthode préférée à une optimisation combinatoire ou à un arbre de décision :
 * le nombre d'alternatives est limité et connu à l'avance, les critères sont
 * hétérogènes en unité, et une méthode transparente se justifie et se fait
 * varier plus facilement devant un comité d'investissement.
 */

import { CRITERIA_KEYS } from './model';
import type { Analysis, Bound, CriterionKey, Ranking, Weights } from './types';

/** Valeur brute de chaque critère. Tous sont à maximiser. */
export const criterionValue: Record<CriterionKey, (a: Analysis) => number | null> = {
  npv: (a) => a.npv,
  irr: (a) => a.irr,
  yield: (a) => a.netYield,
  dscrMargin: (a) => a.dscrMargin,
};

/** Bornes calculées sur les seules alternatives finançables : une alternative
 *  écartée ne doit pas étirer l'échelle des autres. */
export function bounds(analyses: Analysis[]): Record<CriterionKey, Bound> {
  const out = {} as Record<CriterionKey, Bound>;
  CRITERIA_KEYS.forEach((key) => {
    const values = analyses
      .map((a) => criterionValue[key](a))
      .filter((v): v is number => v !== null && Number.isFinite(v));
    out[key] = values.length
      ? { min: Math.min(...values), max: Math.max(...values) }
      : { min: 0, max: 0 };
  });
  return out;
}

/**
 * Note normalisée dans [0, 1]. Trois cas particuliers, tous explicites :
 *  - marge DSCR absente (achat comptant) → 1 : aucun engagement ne peut rompre ;
 *  - TRI indéterminé → 0 : l'indicateur ne peut pas soutenir la comparaison ;
 *  - critère constant sur tout le lot → 1 : il ne discrimine rien.
 */
export function normalise(key: CriterionKey, analysis: Analysis, bound: Bound): number {
  const value = criterionValue[key](analysis);
  if (value === null || !Number.isFinite(value)) {
    return key === 'dscrMargin' && !analysis.hasDebt ? 1 : 0;
  }
  const range = bound.max - bound.min;
  if (range === 0) return 1;
  return (value - bound.min) / range;
}

/** Classe les alternatives finançables, en conservant la contribution de
 *  chaque critère — de quoi expliquer un classement, pas seulement l'afficher. */
export function rank(analyses: Analysis[], weights: Weights): Ranking {
  const feasible = analyses.filter((a) => a.feasible);
  const excluded = analyses.filter((a) => !a.feasible);
  const scale = bounds(feasible);
  const total = CRITERIA_KEYS.reduce((sum, k) => sum + weights[k], 0) || 1;

  const ranked = feasible
    .map((analysis) => {
      const normalized = {} as Weights;
      const contributions = {} as Weights;
      let score = 0;

      CRITERIA_KEYS.forEach((key) => {
        const n = normalise(key, analysis, scale[key]);
        const share = weights[key] / total;
        normalized[key] = n;
        contributions[key] = share * n;
        score += share * n;
      });

      return { analysis, score, normalized, contributions, position: 0 };
    })
    .sort((a, b) => b.score - a.score)
    .map((entry, index) => ({ ...entry, position: index + 1 }));

  return { ranked, excluded, bounds: scale };
}
