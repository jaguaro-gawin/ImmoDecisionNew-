/**
 * Types du domaine.
 *
 * Convention d'unités, tenue par le nommage et vérifiée par le compilateur :
 *   - `…Amount`  : euros ;
 *   - `…Rate`    : pourcentage annuel (4.2 signifie 4,2 %) ;
 *   - `…Years`   : années entières.
 * La conversion en k€ appartient exclusivement à la couche d'affichage.
 */

/** Les quatre critères de décision, tous à maximiser. */
export type CriterionKey = 'npv' | 'irr' | 'yield' | 'dscrMargin';

export type Weights = Record<CriterionKey, number>;

export type TaxRegime = 'none' | 'micro' | 'reel';

/** Hypothèses communes à toutes les alternatives d'un projet.
 *  Horizon et actualisation sont ici, et non sur l'alternative : comparer des
 *  VAN calculées sur des durées différentes reviendrait à comparer deux
 *  échelles. Le type interdit désormais cette erreur. */
export interface Settings {
  horizonYears: number;
  discountRate: number;
  dscrThreshold: number;
  taxRegime: TaxRegime;
  marginalTaxRate: number;
  socialRate: number;
  taxCapitalGain: boolean;
}

/** Un couple (bien, montage de financement) — l'unité de décision. */
export interface Alternative {
  id: string;
  name: string;
  price: number;
  acquisitionFeeRate: number;
  monthlyRent: number;
  vacancyRate: number;
  rentGrowth: number;
  annualCharges: number;
  chargesGrowth: number;
  resaleValue: number;
  downPayment: number;
  loanRate: number;
  loanYears: number;
}

/** Champs numériques saisissables — exclut `id` et `name`. */
export type NumericField = {
  [K in keyof Alternative]: Alternative[K] extends number ? K : never;
}[keyof Alternative];

export interface Project {
  id: string;
  name: string;
  createdAt: string;
  settings: Settings;
  profile: string;
  weights: Weights;
  weightsConfirmed: boolean;
  alternatives: Alternative[];
}

/** Une année de projection. */
export interface ProjectionYear {
  year: number;
  contractualRent: number;
  grossRent: number;
  charges: number;
  /** Loyer net avant service de la dette et avant impôt. */
  noi: number;
  interest: number;
  amortised: number;
  debtService: number;
  balance: number;
  tax: number;
  taxBase: number;
  /** `null` quand aucune dette n'est en cours cette année-là. */
  dscr: number | null;
  netCashflow: number;
}

/** Statut du TRI : un taux introuvable ou multiple est une information à
 *  afficher, pas une erreur à masquer. */
export type IrrStatus = 'ok' | 'multiple' | 'none';

export interface CapitalGain {
  tax: number;
  gain: number;
  incomeTax: number;
  socialTax: number;
}

export interface Analysis {
  id: string;
  name: string;
  alternative: Alternative;

  equity: number;
  principal: number;
  totalCost: number;
  acquisitionFees: number;
  annuity: number;
  interestPaid: number;
  years: ProjectionYear[];
  finalBalance: number;
  capitalGain: CapitalGain;
  exitFlow: number;
  cashflows: number[];

  npv: number;
  irr: number | null;
  irrStatus: IrrStatus;
  unleveredIrr: number | null;
  leverage: number | null;
  signChanges: number;
  payback: number | null;

  hasDebt: boolean;
  dscrMin: number | null;
  weakestYear: number | null;
  dscrMargin: number | null;
  resistance: number | null;
  netYield: number;
  grossYield: number;
  feasible: boolean;
  loanToValue: number;
}

export interface RankedEntry {
  analysis: Analysis;
  score: number;
  position: number;
  normalized: Weights;
  contributions: Weights;
}

export interface Bound { min: number; max: number }

export interface Ranking {
  ranked: RankedEntry[];
  excluded: Analysis[];
  bounds: Record<CriterionKey, Bound>;
}

export type IssueLevel = 'error' | 'warning';

export interface Issue {
  field: string;
  level: IssueLevel;
  message: string;
}
