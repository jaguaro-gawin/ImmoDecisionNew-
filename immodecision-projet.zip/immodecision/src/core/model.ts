/**
 * Modèle — constantes, valeurs par défaut, fabriques et pondération.
 */

import type { Alternative, CriterionKey, Project, Settings, Weights } from './types';

export interface CriterionDefinition {
  key: CriterionKey;
  label: string;
  /** Formulation utilisée dans les phrases générées (« portée par son TRI »). */
  phrase: string;
  hint: string;
}

export const CRITERIA: readonly CriterionDefinition[] = [
  { key: 'npv', label: 'VAN', phrase: 'sa VAN', hint: 'Valeur actuelle nette des flux investisseur' },
  { key: 'irr', label: 'TRI', phrase: 'son TRI', hint: 'Rendement annualisé des fonds propres' },
  { key: 'yield', label: 'Rendement net', phrase: 'son rendement net', hint: 'Performance courante, hors financement' },
  { key: 'dscrMargin', label: 'Marge DSCR', phrase: 'sa marge de sécurité', hint: 'Confort vis-à-vis du seuil bancaire' },
] as const;

export const CRITERIA_KEYS: readonly CriterionKey[] = CRITERIA.map((c) => c.key);

export const PROFILES: Record<string, { label: string; weights: Weights }> = {
  prudent: { label: 'Prudent', weights: { npv: 20, irr: 15, yield: 15, dscrMargin: 50 } },
  equilibre: { label: 'Équilibré', weights: { npv: 30, irr: 30, yield: 15, dscrMargin: 25 } },
  offensif: { label: 'Offensif', weights: { npv: 35, irr: 45, yield: 15, dscrMargin: 5 } },
};

export const TAX_REGIMES = {
  none: { label: 'Non modélisée', hint: 'Flux avant impôt' },
  micro: { label: 'Micro-foncier', hint: 'Abattement forfaitaire de 30 % sur le loyer brut' },
  reel: { label: 'Réel', hint: 'Charges et intérêts déductibles, déficit reportable' },
} as const;

/** Prélèvements sociaux applicables aux revenus fonciers et plus-values. */
export const SOCIAL_RATE = 17.2;

/** Plafond de recettes du micro-foncier — information affichée, non bloquante. */
export const MICRO_CEILING = 15000;

export interface FieldDefinition {
  key: Exclude<keyof Alternative, 'id' | 'name'>;
  label: string;
  unit: string;
  step: number;
  group: 'bien' | 'exploitation' | 'financement' | 'sortie';
}

export const ALTERNATIVE_FIELDS: readonly FieldDefinition[] = [
  { key: 'price', label: 'Prix du bien', unit: '€', step: 1000, group: 'bien' },
  { key: 'acquisitionFeeRate', label: 'Frais d\u2019acquisition', unit: '%', step: 0.1, group: 'bien' },
  { key: 'monthlyRent', label: 'Loyer mensuel brut', unit: '€', step: 10, group: 'exploitation' },
  { key: 'vacancyRate', label: 'Vacance locative', unit: '%', step: 0.5, group: 'exploitation' },
  { key: 'rentGrowth', label: 'Croissance du loyer', unit: '%/an', step: 0.1, group: 'exploitation' },
  { key: 'annualCharges', label: 'Charges annuelles', unit: '€', step: 100, group: 'exploitation' },
  { key: 'chargesGrowth', label: 'Croissance des charges', unit: '%/an', step: 0.1, group: 'exploitation' },
  { key: 'downPayment', label: 'Apport personnel', unit: '€', step: 1000, group: 'financement' },
  { key: 'loanRate', label: 'Taux d\u2019emprunt', unit: '%', step: 0.05, group: 'financement' },
  { key: 'loanYears', label: 'Durée d\u2019emprunt', unit: 'ans', step: 1, group: 'financement' },
  { key: 'resaleValue', label: 'Valeur de revente', unit: '€', step: 1000, group: 'sortie' },
];

export const FIELD_GROUPS = [
  { key: 'bien', label: 'Le bien' },
  { key: 'exploitation', label: 'Exploitation' },
  { key: 'financement', label: 'Financement' },
  { key: 'sortie', label: 'Sortie' },
] as const;

let sequence = 0;
const nextId = (prefix: string): string =>
  `${prefix}_${Date.now().toString(36)}${(sequence++).toString(36)}`;

export function defaultSettings(): Settings {
  return {
    horizonYears: 10,
    discountRate: 4,
    dscrThreshold: 1.2,
    taxRegime: 'none',
    marginalTaxRate: 30,
    socialRate: SOCIAL_RATE,
    taxCapitalGain: false,
  };
}

export function makeAlternative(overrides: Partial<Alternative> = {}): Alternative {
  return {
    id: nextId('alt'),
    name: 'Alternative',
    price: 200000,
    acquisitionFeeRate: 7.5,
    monthlyRent: 1100,
    vacancyRate: 0,
    rentGrowth: 1.5,
    annualCharges: 1800,
    chargesGrowth: 2.5,
    resaleValue: 230000,
    downPayment: 80000,
    loanRate: 4.2,
    loanYears: 20,
    ...overrides,
  };
}

export function makeProject(name = 'Nouveau projet'): Project {
  return {
    id: nextId('prj'),
    name,
    createdAt: new Date().toISOString(),
    settings: defaultSettings(),
    profile: 'equilibre',
    weights: { ...PROFILES.equilibre!.weights },
    weightsConfirmed: false,
    // Trois montages du même bien, choisis pour que le premier écran montre
    // un arbitrage réel : le premier est écarté par la banque malgré le
    // meilleur TRI, les deux autres s'échangent la tête selon les poids.
    alternatives: [
      makeAlternative({ name: 'Apport 80 k€ · 20 ans', downPayment: 80000, loanRate: 4.2, loanYears: 20 }),
      makeAlternative({ name: 'Apport 100 k€ · 20 ans', downPayment: 100000, loanRate: 4.0, loanYears: 20 }),
      makeAlternative({ name: 'Apport 100 k€ · 25 ans', downPayment: 100000, loanRate: 4.15, loanYears: 25 }),
    ],
  };
}

/** Redistribue les poids pour que la somme reste exactement 100 : ce qu'un
 *  critère gagne, les autres le cèdent au prorata. */
export function rebalanceWeights(weights: Weights, key: CriterionKey, value: number): Weights {
  const target = Math.max(0, Math.min(100, Number.isFinite(value) ? value : 0));
  const others = CRITERIA_KEYS.filter((k) => k !== key);
  const remaining = 100 - target;
  const sumOthers = others.reduce((sum, k) => sum + weights[k], 0);

  const next = { ...weights, [key]: target } as Weights;
  if (sumOthers <= 0) others.forEach((k) => { next[k] = remaining / others.length; });
  else others.forEach((k) => { next[k] = (weights[k] / sumOthers) * remaining; });
  return next;
}

/** Arrondi au plus fort reste : les pourcentages affichés totalisent 100. */
export function displayWeights(weights: Weights): Weights {
  const total = CRITERIA_KEYS.reduce((sum, k) => sum + weights[k], 0) || 1;
  const exact = CRITERIA_KEYS.map((k) => ({ k, v: (weights[k] / total) * 100 }));

  const out = {} as Weights;
  let used = 0;
  exact.forEach(({ k, v }) => { out[k] = Math.floor(v); used += out[k]; });

  exact
    .map(({ k, v }) => ({ k, frac: v - Math.floor(v) }))
    .sort((a, b) => b.frac - a.frac)
    .slice(0, 100 - used)
    .forEach(({ k }) => { out[k] += 1; });

  return out;
}
