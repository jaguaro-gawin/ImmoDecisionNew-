/**
 * Fiscalité — revenus fonciers et plus-value de cession.
 *
 * Périmètre : location nue détenue par un particulier résident, hors résidence
 * principale. Les régimes LMNP/LMP, les dispositifs de défiscalisation et la
 * surtaxe sur les plus-values élevées ne sont pas modélisés.
 */

import type { CapitalGain, TaxRegime } from './types';

const MICRO_ALLOWANCE = 0.3;
const CG_INCOME_RATE = 0.19;

export interface RentalTaxResult {
  tax: number;
  base: number;
  /** Déficit foncier à reporter sur les revenus des années suivantes. */
  carriedDeficit: number;
}

export function rentalTax(
  regime: TaxRegime,
  year: { grossRent: number; charges: number; interest: number },
  rates: { marginalTaxRate: number; socialRate: number },
  carriedDeficit = 0,
): RentalTaxResult {
  const rate = (rates.marginalTaxRate + rates.socialRate) / 100;

  if (regime === 'none') return { tax: 0, base: 0, carriedDeficit: 0 };

  if (regime === 'micro') {
    const base = year.grossRent * (1 - MICRO_ALLOWANCE);
    return { tax: base * rate, base, carriedDeficit: 0 };
  }

  const result = year.grossRent - year.charges - year.interest - carriedDeficit;
  if (result < 0) return { tax: 0, base: 0, carriedDeficit: -result };
  return { tax: result * rate, base: result, carriedDeficit: 0 };
}

/** Abattement pour durée de détention — impôt sur le revenu.
 *  6 % par an de la 6e à la 21e année, 4 % la 22e : exonération à 22 ans. */
function incomeAllowance(years: number): number {
  if (years <= 5) return 0;
  if (years >= 22) return 1;
  return (years - 5) * 0.06;
}

/** Abattement pour durée de détention — prélèvements sociaux.
 *  1,65 %/an de la 6e à la 21e, 1,60 % la 22e, 9 % ensuite : exonération à 30 ans. */
function socialAllowance(years: number): number {
  if (years <= 5) return 0;
  if (years >= 30) return 1;
  if (years <= 21) return (years - 5) * 0.0165;
  if (years === 22) return 16 * 0.0165 + 0.016;
  return Math.min(16 * 0.0165 + 0.016 + (years - 22) * 0.09, 1);
}

export function capitalGainTax(
  sale: { resaleValue: number; acquisitionCost: number; holdingYears: number },
  rates: { socialRate: number },
): CapitalGain {
  const gain = sale.resaleValue - sale.acquisitionCost;
  if (gain <= 0) return { tax: 0, gain, incomeTax: 0, socialTax: 0 };

  const incomeTax = gain * (1 - incomeAllowance(sale.holdingYears)) * CG_INCOME_RATE;
  const socialTax = gain * (1 - socialAllowance(sale.holdingYears)) * (rates.socialRate / 100);

  return { tax: incomeTax + socialTax, gain, incomeTax, socialTax };
}
