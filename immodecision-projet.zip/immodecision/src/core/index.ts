/**
 * Moteur de calcul — surface publique.
 *
 * Tout ce qui est exporté ici est une fonction pure : pas de DOM, pas d'état
 * partagé, pas d'effet de bord. Le moteur est utilisable tel quel dans un
 * test, un script Node ou une autre interface.
 */

export * from './types';
export * from './model';
export * from './loan';
export * from './cashflow';
export * from './tax';
export * from './analyze';
export * from './scoring';
export * from './robustness';
export * from './validation';
