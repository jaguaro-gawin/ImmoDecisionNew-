/**
 * État applicatif — Zustand.
 *
 * Le store ne détient que ce qui est *saisi* : projets, alternatives,
 * hypothèses, pondération, position dans le parcours. Aucun résultat chiffré
 * n'y est stocké. Tout ce qui se calcule est dérivé à la lecture, par des
 * hooks mémoïsés : impossible qu'un indicateur affiché soit en retard sur la
 * saisie qui le produit.
 *
 * La persistance passe par le middleware `persist`, qui gère lui-même la
 * sérialisation, la version du schéma et l'absence de stockage local.
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { useMemo } from 'react';

import {
  makeProject, makeAlternative, PROFILES, rebalanceWeights,
} from '../core/model';
import { analyze } from '../core/analyze';
import { rank } from '../core/scoring';
import { stability, tippingPoints, scenarios } from '../core/robustness';
import { validateAlternative, validateSettings } from '../core/validation';
import type {
  Alternative, Analysis, CriterionKey, Issue, Project, Ranking, Settings,
} from '../core/types';

export type StepKey = 'settings' | 'alternatives' | 'priorities' | 'calculations' | 'results';

export const STEPS: readonly { key: StepKey; label: string; caption: string }[] = [
  { key: 'settings', label: 'Hypothèses', caption: 'Horizon, actualisation, exigence bancaire' },
  { key: 'alternatives', label: 'Alternatives', caption: 'Couples bien × financement' },
  { key: 'priorities', label: 'Priorités', caption: 'Pondération des critères' },
  { key: 'calculations', label: 'Calculs', caption: 'Projection année par année' },
  { key: 'results', label: 'Résultat', caption: 'Classement et robustesse' },
];

interface AppState {
  route: 'projects' | 'workspace';
  step: StepKey;
  projects: Project[];
  currentId: string | null;
  focusId: string | null;

  go: (route: 'projects' | 'workspace') => void;
  goStep: (step: StepKey) => void;
  focusAlternative: (id: string) => void;

  createProject: (name?: string) => void;
  openProject: (id: string) => void;
  duplicateProject: (id: string) => void;
  deleteProject: (id: string) => void;
  renameProject: (name: string) => void;

  updateSettings: (patch: Partial<Settings>) => void;
  addAlternative: () => void;
  duplicateAlternative: (id: string) => void;
  removeAlternative: (id: string) => void;
  updateAlternative: (id: string, patch: Partial<Alternative>) => void;

  setWeight: (key: CriterionKey, value: number) => void;
  applyProfile: (key: string) => void;
  confirmWeights: () => void;
}

/**
 * Identifiant du projet courant, avec repli sur le premier de la liste.
 *
 * Le repli n'est pas cosmétique : sans lui, un `currentId` absent — au premier
 * démarrage, ou après la suppression du projet ouvert — ferait porter les
 * modifications sur aucun projet, et les saisies seraient silencieusement
 * perdues. La lecture et l'écriture doivent désigner le même projet.
 */
const currentIdOf = (state: Pick<AppState, 'projects' | 'currentId'>): string | null => {
  if (state.currentId && state.projects.some((p) => p.id === state.currentId)) return state.currentId;
  return state.projects[0]?.id ?? null;
};

/** Applique une transformation au projet courant, sans mutation. */
const withCurrent = (
  state: AppState,
  update: (project: Project) => Project,
): Partial<AppState> => {
  const id = currentIdOf(state);
  return { projects: state.projects.map((p) => (p.id === id ? update(p) : p)) };
};

const initialProject = makeProject('Projet de démonstration');

export const useApp = create<AppState>()(
  persist(
    (set) => ({
      route: 'workspace',
      step: 'settings',
      projects: [initialProject],
      currentId: initialProject.id,
      focusId: null,

      go: (route) => set({ route }),
      goStep: (step) => set({ step }),
      focusAlternative: (focusId) => set({ focusId }),

      createProject: (name) => set((state) => {
        const project = makeProject(name || `Projet ${state.projects.length + 1}`);
        return {
          projects: [project, ...state.projects],
          currentId: project.id,
          route: 'workspace',
          step: 'settings',
        };
      }),

      openProject: (id) => set({ currentId: id, route: 'workspace', step: 'settings' }),

      duplicateProject: (id) => set((state) => {
        const source = state.projects.find((p) => p.id === id);
        if (!source) return {};
        const copy: Project = {
          ...structuredClone(source),
          id: makeProject().id,
          name: `${source.name} (copie)`,
          createdAt: new Date().toISOString(),
        };
        copy.alternatives = copy.alternatives.map((alt) => ({ ...alt, id: makeAlternative().id }));
        return { projects: [copy, ...state.projects] };
      }),

      deleteProject: (id) => set((state) => ({
        projects: state.projects.filter((p) => p.id !== id),
        currentId: state.currentId === id ? null : state.currentId,
        route: state.currentId === id ? 'projects' : state.route,
      })),

      renameProject: (name) => set((state) => withCurrent(state, (p) => ({ ...p, name }))),

      updateSettings: (patch) => set((state) => withCurrent(state, (p) => ({
        ...p,
        settings: { ...p.settings, ...patch },
      }))),

      addAlternative: () => set((state) => withCurrent(state, (p) => {
        const last = p.alternatives[p.alternatives.length - 1];
        const seed = last ? { ...last } : {};
        delete (seed as Partial<Alternative>).id;
        return {
          ...p,
          alternatives: [
            ...p.alternatives,
            makeAlternative({ ...seed, name: `Alternative ${p.alternatives.length + 1}` }),
          ],
        };
      })),

      duplicateAlternative: (id) => set((state) => withCurrent(state, (p) => {
        const index = p.alternatives.findIndex((a) => a.id === id);
        if (index < 0) return p;
        const source = p.alternatives[index]!;
        const copy = makeAlternative({ ...source, name: `${source.name} (variante)` });
        const alternatives = [...p.alternatives];
        alternatives.splice(index + 1, 0, copy);
        return { ...p, alternatives };
      })),

      removeAlternative: (id) => set((state) => withCurrent(state, (p) => (
        p.alternatives.length <= 1
          ? p
          : { ...p, alternatives: p.alternatives.filter((a) => a.id !== id) }
      ))),

      updateAlternative: (id, patch) => set((state) => withCurrent(state, (p) => ({
        ...p,
        alternatives: p.alternatives.map((a) => (a.id === id ? { ...a, ...patch } : a)),
      }))),

      setWeight: (key, value) => set((state) => withCurrent(state, (p) => ({
        ...p,
        weights: rebalanceWeights(p.weights, key, value),
        profile: 'sur-mesure',
      }))),

      applyProfile: (key) => set((state) => {
        const profile = PROFILES[key];
        if (!profile) return {};
        return withCurrent(state, (p) => ({ ...p, weights: { ...profile.weights }, profile: key }));
      }),

      confirmWeights: () => {
        set((state) => withCurrent(state, (p) => ({ ...p, weightsConfirmed: true })));
        set({ step: 'calculations' });
      },
    }),
    {
      name: 'immodecision.v3',
      version: 1,
      storage: createJSONStorage(() => localStorage),
      // La position dans le parcours n'a pas à survivre à un rechargement.
      partialize: (state) => ({ projects: state.projects, currentId: state.currentId }),
    },
  ),
);

/* ── Sélecteurs ─────────────────────────────────────────────────────────── */

export function useCurrentProject(): Project | null {
  const projects = useApp((s) => s.projects);
  const currentId = useApp((s) => s.currentId);
  const id = currentIdOf({ projects, currentId });
  return projects.find((p) => p.id === id) ?? null;
}

export interface Derived {
  analyses: Analysis[];
  ranking: Ranking;
  issues: Map<string, Issue[]>;
  settingsIssues: Issue[];
  invalid: Alternative[];
}

const EMPTY: Derived = {
  analyses: [],
  ranking: { ranked: [], excluded: [], bounds: {} as Ranking['bounds'] },
  issues: new Map(),
  settingsIssues: [],
  invalid: [],
};

/** Analyses, classement et diagnostics du projet courant. */
export function useDerived(): Derived {
  const project = useCurrentProject();

  return useMemo(() => {
    if (!project) return EMPTY;

    const issues = new Map<string, Issue[]>();
    project.alternatives.forEach((alt) => {
      issues.set(alt.id, validateAlternative(alt, project.settings));
    });

    const usable = project.alternatives.filter(
      (alt) => !issues.get(alt.id)!.some((i) => i.level === 'error'),
    );
    const analyses = usable.map((alt) => analyze(alt, project.settings));

    return {
      analyses,
      ranking: rank(analyses, project.weights),
      issues,
      settingsIssues: validateSettings(project.settings),
      invalid: project.alternatives.filter((alt) => issues.get(alt.id)!.some((i) => i.level === 'error')),
    };
  }, [project]);
}

export interface Robustness {
  stability: ReturnType<typeof stability> | null;
  tipping: ReturnType<typeof tippingPoints>;
  scenarios: ReturnType<typeof scenarios>;
}

/** Analyse de robustesse — deux mille classements, calculés seulement quand
 *  l'étape Résultat est à l'écran. */
export function useRobustness(): Robustness | null {
  const project = useCurrentProject();
  const { analyses } = useDerived();

  return useMemo(() => {
    if (!project || analyses.length === 0) return null;
    const feasible = analyses.filter((a) => a.feasible);
    return {
      stability: feasible.length ? stability(feasible, project.weights, { samples: 2000, spread: 25 }) : null,
      tipping: feasible.length > 1 ? tippingPoints(feasible, project.weights) : [],
      scenarios: scenarios(
        project.alternatives.filter((alt) => analyses.some((a) => a.id === alt.id)),
        project.settings,
      ),
    };
  }, [project, analyses]);
}
