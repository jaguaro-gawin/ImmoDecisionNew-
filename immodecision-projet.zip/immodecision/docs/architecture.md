# Architecture

Ce document explique **pourquoi** le code est organisé ainsi. Le « comment » est
dans les fichiers eux-mêmes.

---

## Le principe : une seule direction de dépendance

```
   composants  ──────►  store  ──────►  moteur
  (src/components)   (src/store)     (src/core)
```

Une flèche se lit « dépend de ». Il n'y en a aucune dans l'autre sens : le
moteur ignore l'existence de React, le store ignore l'existence des écrans.
C'est ce qui rend le moteur testable sans navigateur — les trente tests de
`test/engine.test.ts` tournent en environnement Node pur.

### `src/core` — le moteur

Uniquement des fonctions pures. Aucun accès au DOM, aucune variable partagée,
aucun effet de bord. Deux appels avec les mêmes arguments donnent le même
résultat, y compris l'analyse de robustesse, dont le générateur aléatoire est
déterministe.

| Fichier | Responsabilité |
|---------|----------------|
| `types.ts` | Le contrat du domaine — c'est le fichier à lire en premier |
| `model.ts` | Constantes, valeurs par défaut, fabriques, pondération |
| `loan.ts` | Échéancier à annuités constantes |
| `cashflow.ts` | VAN, TRI, délai de récupération |
| `tax.ts` | Revenus fonciers, plus-value de cession |
| `analyze.ts` | Projection annuelle et indicateurs d'une alternative |
| `scoring.ts` | Normalisation min-max, score pondéré, classement |
| `robustness.ts` | Stabilité aux poids, points de bascule, chocs |
| `validation.ts` | Contrôle des saisies, deux niveaux de gravité |

**Ce que les types achètent.** Le domaine est entièrement numérique, et ses
unités se confondent facilement : un taux, un montant et un ratio sont tous des
`number`. Les types documentent la convention (`…Rate` en pourcentage, `…Amount`
en euros, `…Years` en années) et, surtout, rendent visibles les valeurs
absentes : `irr: number | null` oblige chaque appelant à traiter le cas où le
TRI n'existe pas, là où la version précédente pouvait l'oublier sans bruit. Le
mode `strict` et `noUncheckedIndexedAccess` étendent la même exigence aux accès
par index.

**Convention d'unités, sans exception :** tous les montants sont en euros, tous
les taux en pourcentage, toutes les durées en années. La conversion en k€
appartient au formatage, jamais au calcul.

### `src/store` — l'état

Un store Zustand détient la totalité de l'état *saisi* : projets, alternatives,
hypothèses, pondération, position dans le parcours.

**Rien de dérivé n'y est stocké.** Aucune VAN, aucun DSCR, aucun classement ne
vit dans l'état : tout est recalculé à la lecture par `useDerived()`, mémoïsé sur
la référence du projet. Il devient donc impossible qu'un indicateur affiché soit
en retard sur la saisie qui le produit — la classe de bug la plus coûteuse dans
un outil de ce type. L'analyse de robustesse, deux mille classements, a son
propre hook et n'est calculée qu'à l'ouverture de l'étape Résultat.

Le middleware `persist` porte la sauvegarde locale : sérialisation, version du
schéma, et repli silencieux quand le navigateur refuse le stockage (navigation
privée, iframe). `partialize` exclut volontairement la position dans le
parcours, qui n'a pas à survivre à un rechargement.

**Un piège, corrigé par le test de bout en bout.** Les mutations ciblent le
projet courant. Tant que la lecture (`useCurrentProject`) et l'écriture
(`withCurrent`) résolvaient ce projet différemment — l'une avec un repli sur le
premier de la liste, l'autre non — les modifications portaient sur aucun projet
et étaient perdues sans erreur. Les deux passent désormais par la même fonction
`currentIdOf`.

### `src/components` — l'interface

Une vue par étape, des composants de présentation sans état dans `ui/`, les
graphiques dans `charts/`.

---

## Ce que React apporte concrètement

La version précédente reconstruisait la vue entière à chaque frappe, puis
restaurait à la main le focus et la position du curseur en repérant l'élément
actif par un attribut. Cette mécanique fonctionnait, mais il fallait la
maintenir, et elle avait laissé passer un bug : le champ édité était réécrit à
chaque frappe, si bien que taper « 4,2 » voyait la virgule effacée — la valeur
remontée valant déjà 4 — et produisait « 42 ».

React conserve le nœud DOM entre deux rendus : le focus et le curseur ne bougent
pas, et le code qui les gérait a disparu. Le seul point restant est propre au
domaine : un champ contrôlé réécrirait quand même la valeur pendant la frappe.
`NumberField` garde donc un brouillon local tant qu'il a le focus, et le relâche
au `blur`, où la mise en forme (séparateurs de milliers) reprend la main. Ce
comportement est verrouillé par un test qui tape « 4,25 » caractère par
caractère dans un vrai navigateur.

---

## Le build : pourquoi il existe

La livraison attendue est un fichier ouvrable par double-clic, sans serveur.
`vite-plugin-singlefile` inline le JavaScript et la feuille de style dans
`dist/index.html`.

Le fichier pèse environ 660 Ko contre 136 Ko pour la version sans framework.
React et Recharts expliquent l'essentiel de l'écart. C'est le prix assumé de la
solidité : le fichier est local, chargé une fois, sans requête réseau — sur un
site public, l'arbitrage serait différent.

---

## Tests

- `npm test` — trente tests du moteur en environnement Node. Ils incluent la
  **non-régression sur l'exemple publié** dans la fiche descriptive d'origine
  (échéance 8,99 k€, DSCR 1,269, VAN 51,54 k€, TRI 9,889 %), les cas limites
  (taux nul, achat comptant, prêt plus court que la détention, moins-value) et
  les invariants (les poids somment à 100, les fréquences de victoire somment
  à 1).
- `npm run typecheck` — TypeScript strict, exécuté aussi avant chaque build.
- `npm run screenshots` — parcours complet du fichier livré dans Chromium :
  navigation entre les cinq étapes, saisie décimale, somme des poids, rendu des
  graphiques, absence d'erreur console. Écrit une capture par écran, parce
  qu'une suite de tests dit qu'un bouton existe mais pas qu'il est lisible.

---

## Ce qui n'a pas été fait, et pourquoi

**Aucun routeur.** Cinq étapes dans un parcours linéaire, sans URL à partager ni
navigation profonde : une clé d'étape dans le store suffit. Un routeur
ajouterait une dépendance et une indirection pour rien.

**Aucune bibliothèque de composants.** La feuille de style est écrite pour ce
produit ; importer un système de design complet pour cinq écrans coûterait plus
en contraintes qu'il ne ferait gagner.

**Aucune persistance serveur.** Les données restent sur le poste. Un outil
d'arbitrage patrimonial manipule des informations que l'utilisateur n'a aucune
raison de confier à un tiers.

**Aucune authentification.** La toute première version affichait un écran de
connexion avec un mot de passe en clair dans le code. Une authentification qui
ne protège rien donne une fausse impression de sécurité ; elle a été retirée
plutôt que maquillée.
